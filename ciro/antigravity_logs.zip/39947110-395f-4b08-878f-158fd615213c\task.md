# Execution Tasks

- [x] Fix Next.js 15 async `params` bug in `[slug]/page.tsx`.
- [x] Generate 7 realistic UI mockup images.
- [x] Move generated images to `public/projects/`.
- [x] Add `image` field to `projects.ts`.
- [x] Update Homepage grid to render project images.
- [x] Update Case Study layout to render massive hero image.
