# Fix Mobile Responsiveness, Permissions & Video Streaming

The mobile developer reports three critical issues when using the Date Night web app in a mobile WebView: the game is not mobile responsive, camera/microphone permission prompts don't appear, and the video date always shows "Waiting for your date" with streaming not working.

## Root Cause Analysis

| Issue | Root Cause |
|---|---|
| Not mobile responsive | Phaser game configured at 1280×720 landscape with `FIT` mode — on portrait phones it renders tiny. No `viewport` meta tag in `layout.tsx`. Phaser scenes use hardcoded pixel coordinates based on 1280×720. |
| Permissions not requested | `VideoContainer` calls `videoService.init()` → `videoService.startLocalVideo()` which calls Zego's `createStream()`. If this fails (permission denied in WebView), the error is caught and silently swallowed — no UI feedback or retry mechanism. |
| "Waiting for date" always shown | The `hasRemoteVideo` state only becomes `true` when the remote `<video>` element fires `loadeddata`/`playing`. If video init itself fails, neither local nor remote video ever connects, so the placeholder stays visible forever. |

## Proposed Changes

### Layout & Viewport

#### [MODIFY] [layout.tsx](file:///f:/Git/game-project/client/app/layout.tsx)
- Add `<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />` to `<head>` for proper mobile scaling.

---

### Phaser Game Scaling

#### [MODIFY] [dateNightGame.ts](file:///f:/Git/game-project/client/game/dateNightGame.ts)
- Change Phaser scale mode from `FIT` (1280×720 landscape) to `RESIZE` mode so the canvas fills the entire parent container and adapts to any screen size.
- Remove fixed `width`/`height` — let the game use the parent element's dimensions.

#### [MODIFY] [LobbyScene.ts](file:///f:/Git/game-project/client/game/scenes/LobbyScene.ts)
- Fix duplicate `DEFAULT_PROFILE_IMAGE` property declaration (lines 10-11).
- Make font sizes, card dimensions, and button sizes responsive using `Math.min(width, height)` ratios instead of hardcoded pixel values so the scene works on both landscape and portrait screens.

#### [MODIFY] [WaitingRoomScene.ts](file:///f:/Git/game-project/client/game/scenes/WaitingRoomScene.ts)
- Make font sizes, radar positions, card dimensions, and button sizes responsive to actual screen dimensions, particularly for portrait mobile screens.

#### [MODIFY] [GiftSelectionScene.ts](file:///f:/Git/game-project/client/game/scenes/GiftSelectionScene.ts)
- Scale UI elements relative to screen dimensions for mobile portrait.

---

### Camera/Mic Permissions & Video Streaming

#### [MODIFY] [VideoContainer.tsx](file:///f:/Git/game-project/client/components/DateNight/VideoContainer.tsx)
- Add explicit permissions state tracking (`permissionState`): `'checking'`, `'granted'`, `'denied'`, `'error'`.
- Before initializing Zego, call `navigator.mediaDevices.getUserMedia({ video: true, audio: true })` to trigger the browser/WebView permission prompt.
- Show a clear UI when permissions are denied: a button to re-request or instructions to enable in settings.
- Show a clear error state when video initialization fails instead of silently showing "Waiting for your date".
- For Flutter WebView: send a `FlutterBridge.postMessage('request_permissions', { camera: true, microphone: true })` message so the Flutter side can trigger native permission dialogs.

#### [MODIFY] [videoService.ts](file:///f:/Git/game-project/client/lib/services/videoService.ts)
- Add a `requestPermissions()` method that explicitly calls `getUserMedia` to trigger the browser permission prompt before Zego initialization.
- Return clear error types so the UI can show appropriate messaging.

#### [MODIFY] [AudioRecorder.tsx](file:///f:/Git/game-project/client/components/DateNight/AudioRecorder.tsx)
- Add a Flutter-aware permission request: send `request_permissions` message via `FlutterBridge` before calling `getUserMedia`.
- Add a "Grant Permission" button that re-attempts microphone access when permission is denied.

---

### Flutter Bridge Enhancement

#### [MODIFY] [flutterBridge.ts](file:///f:/Git/game-project/client/lib/utils/flutterBridge.ts)
- Add `REQUEST_PERMISSIONS` event type.
- Add `requestPermissions(permissions: { camera?: boolean, microphone?: boolean })` convenience method.

## Verification Plan

### Browser Testing (Visual + Functional)
1. Open the app at `http://localhost:3000/date-night` in a mobile-sized browser window (375×812 for iPhone, 360×800 for Android)
2. Verify the Phaser lobby scene fills the screen properly in portrait mode
3. Verify text and buttons are readable and tappable at mobile sizes
4. Verify the "Waiting for date" screen layout works on mobile
5. Confirm camera/microphone permission prompt appears (on desktop Chrome at least)

### Manual Verification (by mobile developer)
Since the issues are specifically about Flutter WebView behavior, the final verification must be done by the mobile developer on an actual device:
1. Load the game in the Flutter WebView
2. Verify the game displays properly in portrait orientation
3. Verify camera/microphone permission dialogs appear when entering video date
4. Verify the "Waiting for date" screen shows appropriate error/prompt when permissions are denied
5. Test the audio recorder component permission flow
