# CIRO Integration and Extension — Task Tracker

## Layer A: Backend Integration
- `[x]` A1: Antigravity orchestration layer (`backend/antigravity_runtime.py`)
- `[x]` A2: Multi-crisis pipeline coordinator (`backend/agents/multi_coordinator.py`) + `/api/analyze/multi`
- `[x]` A3: Citizen report verifier agent (Vision/Text credibility scoring)
- `[x]` A4: NASA FIRMS / PMD / NDMA weather/hotspot data tools
- `[x]` A5: Loss aggregation tool (traffic, logistical, economic, environmental losses)
- `[x]` A6: Rule-based baseline scorer (`backend/baseline/rule_based.py`)
- `[x]` A7: Agent trace export endpoint (`/api/logs/export`)
- `[x]` A8: Test mode backend configuration

## Layer B: Admin Panel Live Wiring
- `[x]` B1: Replace `DEMO_CRISES` in `AppShell.tsx` with live backend feed + Firestore sync
- `[x]` B2: Wire `/comparison` page to real baseline endpoint `/api/baseline/score`
- `[x]` B3: Map page dynamic multi-incident markers rendering
- `[x]` B4: Test mode UI settings page controls
- `[x]` B5: Wire `impact/page.tsx` to loss aggregator output

## Layer C: Mobile App Extensions
- `[x]` C1: Sidebar navigation drawer for mobile
- `[x]` C2: Before/after routing panel in `ResultScreen.tsx`
- `[x]` C3: Active Crises tile on dispatcher dashboard

## Layer D: Deliverables & Polish
- `[x]` D1: Demo video script (`ciro/demo/script.md`)
- `[x]` D2: Sample run trace JSON (`ciro/demo/sample_run_trace.json`)
- `[x]` D3: Update `README.md` (agent count, Antigravity role, requirements mapping)
