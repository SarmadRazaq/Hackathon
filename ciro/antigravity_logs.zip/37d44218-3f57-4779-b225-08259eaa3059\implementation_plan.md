# SWE-bench Integration Implementation Plan

## Background

This project is a **Dynamic Recursive Verification (DRV)** agentic research system.
It already has foundational SWE-bench support:

- **`swebench_runner.py`** — orchestrates DRV over SWE-bench JSONL/JSON instance files
- **`environment_wrapper.py`** — `SWEBenchWorkspaceEnvironment` runs shell commands in a workspace
- **`eval.py`** — evaluation harness that supports `--benchmark-env swebench`

However, the current setup has these **critical gaps** that prevent end-to-end SWE-bench evaluation:

1. **No dataset fetching** — there is no code to pull instances from HuggingFace (`SWE-bench/SWE-bench_Lite`)
2. **No git clone / checkout** — SWE-bench requires each repo to be cloned at `base_commit`
3. **No patch application or diff generation** — the agent must produce a unified diff
4. **No official evaluation scoring** — the runner uses ad-hoc `pytest -q` but SWE-bench scoring requires applying the test patch and verifying `FAIL_TO_PASS` specifically
5. **Executor tool budget too small** — 5 tool calls is far too few for a code-fix task; needs to be configurable
6. **No `run_command` tool for the executor** — the ReAct loop cannot run shell commands directly (needed for `git diff`, `python`, test runs)
7. **`swebench_runner.py` self-test lacks a real smoke test** — `_self_test_instances()` doesn't exercise git or test scoring

## Proposed Changes

---

### Component 1: Dataset Fetcher — `swebench_dataset.py` [NEW]

Thin wrapper to download and cache SWE-bench instances locally.

#### [NEW] swebench_dataset.py
- Function `fetch_swebench_lite(cache_dir, split="test")` using `datasets` library (HuggingFace)
- Serializes to JSONL at `<cache_dir>/swebench_lite.jsonl`
- Falls back to reading from the cache if already present
- Also provides `fetch_swebench_verified()` and `fetch_swebench_full()`
- Returns `list[dict]` compatible with `_load_instances()` in `swebench_runner.py`

---

### Component 2: Repo Setup Utilities — `swebench_repo_setup.py` [NEW]

Git clone + checkout for each instance. This is the heaviest prerequisite.

#### [NEW] swebench_repo_setup.py
- `clone_or_update(repo, repos_root) -> Path` — clones `https://github.com/<repo>` if absent
- `checkout_base_commit(repo_path, base_commit)` — runs `git checkout <base_commit>`
- `apply_test_patch(repo_path, test_patch_content)` — applies the `test_patch` field from the instance so that `FAIL_TO_PASS` tests are present
- `extract_agent_patch(repo_path, base_commit) -> str` — runs `git diff <base_commit>` to get what the agent changed
- `reset_to_base(repo_path, base_commit)` — hard resets repo to base before running next instance

---

### Component 3: Scoring Logic — `swebench_scorer.py` [NEW]

Proper SWE-bench success criterion:
- `score_instance(repo_path, fail_to_pass, pass_to_pass, timeout) -> ScoringResult`
- Runs pytest targeting only the `FAIL_TO_PASS` test IDs and verifies they now pass
- Runs pytest on `PASS_TO_PASS` tests and verifies no regressions
- Returns a `ScoringResult(dataclass)` with `f2p_passed`, `p2p_passed`, `resolved`, `output`

---

### Component 4: Extended Executor Tools — `executor.py` [MODIFY]

Add a `run_shell_command` tool to the ReAct loop so the agent can:
- Run `git status`, `python script.py`, `pytest tests/`, `grep`, etc.
- Have configurable max tool calls (`max_tool_calls` param, default stays 5 but SWE-bench runner passes 15)

#### [MODIFY] executor.py
- Add `run_shell_command(command_with_cwd: str) -> str` tool  
  Input format: `{"command": "...", "cwd": "..."}` JSON or plain string
- Add `run_tests(test_ids_and_cwd: str) -> str` tool  
  Input: `{"tests": [...], "cwd": "..."}` — runs `pytest -x` on specific test IDs
- Expose `max_tool_calls` parameter in `execute_task()` signature (default=5)
- Update `get_default_tools()` to include the new tools

---

### Component 5: Updated SWE-bench Runner — `swebench_runner.py` [MODIFY]

Wire together dataset fetch, repo setup, agent execution, patch extraction, and scoring.

#### [MODIFY] swebench_runner.py
- Import `swebench_dataset`, `swebench_repo_setup`, `swebench_scorer`
- Add `--fetch-dataset` flag: if set, downloads SWE-bench Lite to `--instances-path` location
- Add `--repos-root` automatic clone: call `clone_or_update` + `checkout_base_commit` before each run
- Add `--apply-test-patch` flag: applies the `test_patch` field before scoring
- Post-run: call `extract_agent_patch()` and store in results
- Post-run: call `score_instance()` instead of raw `pytest -q`
- Add `--max-tool-calls` flag (passed through to `execute_task`)
- Add `agent_patch` and `f2p_passed`/`p2p_passed` columns to CSV/JSONL output
- Extended `_print_summary()` to show SWE-bench `resolved` rate

---

### Component 6: CLI Entry Point — `run_swebench.py` [NEW]

A clean, user-friendly CLI wrapper for the whole pipeline:

```
python run_swebench.py \
  --fetch-dataset lite \
  --repos-root ./repos \
  --max-instances 5 \
  --model llama-3.3-70b-versatile
```

Steps it performs:
1. Fetch dataset (or load from cache)
2. For each instance: clone repo → checkout base → apply test patch
3. Run DRV agent
4. Extract git diff
5. Score with SWE-bench criterion
6. Write CSV + JSONL results + print summary

---

## Verification Plan

### Automated Tests
- `python swebench_dataset.py --self-test` — verifies fetch/cache round-trip
- `python swebench_repo_setup.py --self-test` — verifies clone/checkout/patch/reset on a tiny repo
- `python swebench_scorer.py --self-test` — verifies scoring logic against a fixture
- `python swebench_runner.py --self-test` — existing mock-client self-test (still passes)
- `python run_swebench.py --dry-run --max-instances 1` — end-to-end dry run without LLM calls

### Manual Verification
- Run `python run_swebench.py --fetch-dataset lite --max-instances 2 --repos-root ./repos` and check that CSV has `resolved` column and results are plausible

## Open Questions

> [!IMPORTANT]
> **Docker vs. bare-metal execution**: The official SWE-bench evaluator runs each instance in Docker to ensure clean environments. This plan uses bare git clone + reset instead. That is sufficient for a research prototype but may differ from official leaderboard scoring. Should we add Docker support?

> [!IMPORTANT]
> **Which dataset split?** SWE-bench has three variants: Full (~2294 instances), Lite (~300), and Verified (~500). This plan defaults to **Lite** for speed. Please confirm.

> [!NOTE]
> **API costs**: Running DRV on even 10 SWE-bench instances with Groq's `llama-3.3-70b-versatile` will consume a significant number of tokens (estimated 50k–200k per instance). The `--max-instances` flag will be the primary cost control.
