# implementation_plan.md

## Goal Description
Update the rose gifting system to reflect new point values and lore.

## User Review Required
> [!NOTE]
> **Point Update**: All rose values will be multiplied by 10.
> **Lore Update**: The '99 Roses' description will be rewritten to emphasize trust and confidence.

## Proposed Changes

### Client

#### [MODIFY] [RoseSelector.tsx](file:///f:/Git/game-project/client/components/DateNight/RoseSelector.tsx)
- Update `ROSE_OPTIONS` constant:
  - Multiply all `points` by 10.
  - Rewrite `description` for '99 Roses' to emphasize trust and freedom.

#### [STRIKETHROUGH] [gameConfig.ts]
- (Found that rose options are in `RoseSelector.tsx`, so no changes needed here).

## Verification Plan

### Manual Verification
- **UI Check**: Open the Date Night modal/screen where roses are selected.
- **Verify**:
    1.  Check that prices/points are 10x the previous amount.
    2.  Read the '99 Roses' description to ensure it matches the new lore.
