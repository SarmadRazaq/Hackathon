# Debugging 400 Error: No valid fields to update

- [x] Investigate Flutter code for profile update calls <!-- id: 0 -->
- [x] Identify which fields are being sent in the request <!-- id: 1 -->
- [x] Compare Flutter request body with backend `allowedFields` <!-- id: 2 -->
- [x] Fix the mismatch (either update backend allowed fields or fix flutter payload) <!-- id: 3 -->
- [x] Verify the fix <!-- id: 4 -->

# Refactor Login Screen UI

- [x] Update `LoginScreen` structure to match `CreateAccountScreen` <!-- id: 5 -->
- [x] Add car image and style input fields <!-- id: 6 -->
- [x] Ensure back button navigates to Get Started <!-- id: 7 -->
