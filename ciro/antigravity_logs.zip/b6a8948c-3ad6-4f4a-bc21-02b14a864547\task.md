# Mobile Issues Fix — Date Night Game

## Issues Reported
1. Not mobile responsive
2. Camera/microphone permissions not being requested / option to allow not showing
3. Always displays "Waiting for date" — live streaming not working

## Tasks

- [x] **1. Add viewport meta tag** (`layout.tsx`)
- [x] **2. Fix Phaser game scaling for mobile** (`dateNightGame.ts`, `LobbyScene.ts`, `WaitingRoomScene.ts`)
- [x] **3. Fix camera/mic permissions & video initialization** (`VideoContainer.tsx`, `videoService.ts`)
- [x] **4. Fix AudioRecorder permission handling for WebView** (`AudioRecorder.tsx`)
- [x] **5. Fix duplicate property in LobbyScene** (`LobbyScene.ts`)
- [x] **6. Verify all fixes via build check**
