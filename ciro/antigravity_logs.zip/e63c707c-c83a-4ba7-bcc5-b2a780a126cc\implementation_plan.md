# Implementation Plan — Batch 1 Foundation, Google Maps & Mobile Impact Fixes

This plan outlines the implementation details for Batch 1 (Foundation) along with immediately resolving the Google Maps rendering issue and the $0.0M impact dashboard display bug.

## User Review Required

> [!IMPORTANT]
> 1. **Google Maps Key**: We are reusing the functional `GOOGLE_MAPS_API_KEY` from the backend configuration (`AIzaSyAdoAZKOyWNl3dt-m-oIbAHu-ZCy1HKuDc`) for the mobile app's Map SDK.
> 2. **Firebase Integration**: The Next.js admin panel does not currently have the `firebase` npm library installed. We will install it and configure the Firestore listeners in the browser.

## Proposed Changes

---

### Component: Mobile Client

#### [MODIFY] [mobile/.env](file:///f:/Hackathon/ciro/mobile/.env)
* Add `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY=AIzaSyAdoAZKOyWNl3dt-m-oIbAHu-ZCy1HKuDc` to allow the Expo Maps SDK to render maps correctly.

#### [MODIFY] [ResultScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/ResultScreen.tsx)
* Map the backend's `/api/impact/{crisis_id}` response properties (`traffic`, `economic`, `environmental`, `logistical`) to the specific nested structure expected by the mobile client's rendering logic (`traffic_loss`, `economic_loss`, etc.), formatting values dynamically as USD millions to display correctly on the dashboard.

---

### Component: Backend (FastAPI)

#### [MODIFY] [main.py](file:///f:/Hackathon/ciro/backend/main.py)
* **Antigravity Wrapping (A1)**: Redirect the streaming endpoints (`analyze_custom_stream` and `analyze_scenario_stream`) to call `runtime.stream_pipeline` instead of importing from `agents.orchestrator` directly.
* **Global SSE Events (B1)**: 
  * Add a global `sse_manager` to track active client connections.
  * Define a GET `/api/events` endpoint to allow admin panels to subscribe to live pipeline updates.
  * Wrap pipeline execution streams to broadcast yielded chunks to the `sse_manager`.

---

### Component: Admin Panel (Next.js)

#### [MODIFY] [package.json](file:///f:/Hackathon/ciro/admin_panel/package.json)
* Add `firebase` (v10+) as a dependency to support real-time Firestore connections in the admin shell.

#### [NEW] [firebase.ts](file:///f:/Hackathon/ciro/admin_panel/src/services/firebase.ts)
* Initialize Firebase App and Firestore database with the project credentials.

#### [MODIFY] [AppShell.tsx](file:///f:/Hackathon/ciro/admin_panel/src/components/layout/AppShell.tsx)
* Replace the `DEMO_CRISES` and `DEMO_REPORTS` mock data arrays with:
  1. Live Firestore `onSnapshot` query on the `reports` collection.
  2. Live Firestore `onSnapshot` query on the `incidents` collection (mapping the nested LLM outputs to the frontend `CrisisEvent` structure).
  3. Live SSE subscription (`EventSource`) to `http://localhost:8000/api/events` to stream log details.
* Dynamically compute resource allocation totals and deployment metrics based on active crises rather than static mocks.

## Verification Plan

### Automated Tests
* Run compilation check on backend and frontend:
  * Backend: Run `pytest` or execute `verify_guardrails.py` to ensure core pipeline runs.
  * Mobile: Run `npx tsc --noEmit` from `mobile` directory.

### Manual Verification
1. **Google Maps**: Run the mobile app, go to map view, verify that Google Maps renders correctly.
2. **Mobile Impact Dashboard**: Trigger an incident simulation, navigate to the "Impact" tab on the results screen, and check that it displays non-zero figures matching the crisis severity.
3. **Live Command Center**: Open the admin panel, trigger a crisis from the mobile app (or via settings), and confirm that the Command Center UI updates in real-time without refreshing.
4. **SSE Event Stream**: Verify that the live agent logs stream dynamically into the admin panel as the pipeline executes.
