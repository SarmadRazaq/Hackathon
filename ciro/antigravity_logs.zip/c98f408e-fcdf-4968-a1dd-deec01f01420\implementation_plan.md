# Full Project Audit: Executive Dashboard Failures

I have completed a deep audit of the entire codebase, including the previously untouched `AnalyticsScreen.tsx` (the Executive Dashboard). 

I found a **critical data parsing bug** that will cause your analytics charts to display completely broken data during the presentation.

## Identified Failures

### 1. Analytics Dashboard Shows 100% "Unknown" & "Low" Data (CRITICAL)
- **Where:** `mobile/src/screens/AnalyticsScreen.tsx` (Lines 76 & 79)
- **The Issue:** The analytics screen fetches historical incidents from Firebase to populate the Pie Chart, Bar Chart, and Heatmap. 
  - To get the incident type, it looks for `inc.inputs?.crisis_type`. **This field does not exist in your database schema.** The crisis type is actually generated dynamically by the AI and hidden inside a JSON string at `inc.agent_outputs.ingested_signals`.
  - To get the severity, it looks for `inc.detectedSeverity`. **This field is never saved to the database.** It is calculated on-the-fly in the `ResultScreen`.
- **The Result:** During your live demo, the Pie Chart will say every single incident is "Unknown", the Bar Chart will say every incident is "Low" severity, and the Heatmap will plot entirely blue markers labeled "Unknown". This will look like a massive failure of the AI system to the judges.

## Proposed Fixes

### [MODIFY] [AnalyticsScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/AnalyticsScreen.tsx)
- **Dynamic Type Extraction:** I will add a `try/catch` JSON parser inside the analytics loop to dig into `inc.agent_outputs.ingested_signals` and extract the real `crisis_type` that the AI detected.
- **Dynamic Severity Extraction:** I will port over the severity detection logic from `ResultScreen.tsx`. It will scan `inc.agent_outputs.crisis_assessment` for "CRITICAL", "HIGH", or "LOW" keywords on-the-fly before plotting the charts.
- **The Result:** Your dashboard will instantly populate with gorgeous, accurate data (e.g., 2 Critical Flash Floods, 1 High Heatwave) perfectly categorized.

## User Review Required

> [!IMPORTANT]
> The Executive Dashboard is currently broken due to this schema mismatch. Shall I implement these parsing fixes so the charts look professional for the judges?
