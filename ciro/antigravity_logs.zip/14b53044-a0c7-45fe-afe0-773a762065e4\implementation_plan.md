# Refactor Login Screen UI

Goal: Update the `LoginScreen` to visually match the `CreateAccountScreen` while retaining all existing login functionality (email/pass, biometric, social auth) and ensuring the back button returns to the "Get Started" (Splash) screen.

## Proposed Changes

### Mobile App
#### [MODIFY] [login_screen.dart](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/lib/features/auth/screens/login_screen.dart)
-   **UI Structure**: Adopt the `SingleChildScrollView` + `Column` layout from `CreateAccountScreen`.
-   **AppBar**: Replace `CustomAppBar` with a transparent `AppBar` containing a back arrow and centered "Login" title.
-   **Header**: Update header text style and placement to match "Enter your details" on the signup screen.
-   **Image**: Add the `assets/images/screen-5-car.png` image between the header and inputs.
-   **Input Fields**: Replace `CustomTextField` with direct `TextFormField` widgets using the specific dark theme styling (`fillColor: Color(0xFF1A1A1A)`, `OutlineInputBorder` radius 14) from `CreateAccountScreen`.
-   **Buttons**: Ensure the "Login" button matches the "Save & Continue" button style.
-   **Navigation**: The `Navigator.pop(context)` in the new AppBar will automatically return to the `SplashScreen` (Get Started) since `SplashScreen` pushes `LoginScreen` onto the stack.

## Verification
1.  **Manual Test**:
    *   Launch app (Splash Screen).
    *   Tap "Login".
    *   Verify UI matches "Create Account" style (header, image, input styles).
    *   Tap "Back" arrow -> Should return to Splash Screen.
    *   Test Login -> Should still work.
