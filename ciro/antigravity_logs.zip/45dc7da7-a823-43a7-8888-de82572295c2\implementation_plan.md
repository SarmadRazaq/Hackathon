# Earnings Screen Redesign

## Goal
Implement a premium, data-rich Earnings Screen matching the provided design.
Features:
- Dynamic "Today's Earnings" Arc Progress.
- Weekly Bar Chart.
- Monthly Bar Chart.
- Payout Methods breakdown.
- Payout History list.
- All data fed from backend.

## UI Components
1.  **EarningsHeader**: "Earnings" title.
2.  **TodayEarningsCard**:
    - Arc Progress Bar (Custom Painter or Package).
    - Total Amount centered.
    - Stats Row: Total Rides, Total Time, Total Tips.
    - Buttons: "Set Goal", "View Rides".
3.  **WeeklyEarningsChart**:
    - Title: "This Week's Earnings".
    - Stats Row: Total Rides, Total Amount, Total Tips.
    - Bar Chart (Mon-Sun).
4.  **MonthlyEarningsChart**:
    - Title: "This Month's Earnings".
    - Stats Row.
    - Bar Chart (Jan-Dec).
5.  **PayoutMethodsCard**:
    - Breakdown of In-app vs Cash.
6.  **PayoutHistoryList**:
    - Recent payouts.

## Backend Integration
- **Endpoint**: `/api/v1/driver/earnings/dashboard` (New)
    - Returns:
        - `today`: { amount, trips, onlineTime, tips, goal }
        - `week`: { amount, trips, tips, dailyBreakdown: [] }
        - `month`: { amount, trips, tips, monthlyBreakdown: [] }
        - `payouts`: { recent: [], methods: { inApp, cash } }

## Stack
- **Charts**: `fl_chart` package (Standard for Flutter charts).
- **Arc**: `percent_indicator` or custom `CustomPaint`.

## Plan
1.  **Dependencies**: Add `fl_chart`.
2.  **Domain**: Define `EarningsDashboard` model.
3.  **Data**: Create `EarningsService` and `EarningsProvider`.
4.  **UI Construction**: Build widgets one by one.
5.  **Integration**: Connect UI to Provider.
