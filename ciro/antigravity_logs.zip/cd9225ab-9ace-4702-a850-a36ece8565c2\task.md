# Unhabit Review Task

- [x] Explore project structure (`src`, `backend`).
- [x] Audit API integration & check for mock data in frontend (`src`).
  - [x] `StatsScreen.tsx` (Proper API integration, falls back to default empty state)
  - [x] `NotificationsScreen.tsx`
  - [x] `BuddiesScreen.tsx`
- [x] Audit push notifications implementation (`NotificationManager.tsx` handles Expo tokens).
- [x] Audit Edge Cases and Functionality in Frontend Screens.
  - [x] `HomeScreen.tsx` (Found stubbed logic in `handleRestartJourney`)
  - [x] `Dashboard.tsx` (Minor fallback mock data for journey)
  - [x] `HabitManagementScreen.tsx` (Inputs for description and category are not sent to backend)
  - [x] `ChallengesScreen.tsx` (Good)
  - [x] `ProfileScreen.tsx` (Good)
- [x] Compile review report and implementation plan.
