# Task: Refactor Settings & Support Screens

- [x] Analyze Current Structure <!-- id: 0 -->
    - [x] Review `ProfileScreen.tsx` logic to extract <!-- id: 1 -->
    - [x] Review `RootNavigator.tsx` for route registration <!-- id: 2 -->
- [x] Create New Screens <!-- id: 3 -->
    - [x] Create `src/screens/settings/SettingsScreen.tsx` <!-- id: 4 -->
    - [x] Create `src/screens/settings/SupportScreen.tsx` <!-- id: 5 -->
    - [x] Create `src/screens/settings/EditProfileScreen.tsx` (Implemented as Configurable Modal in Settings) <!-- id: 6 -->
    - [x] Create `src/screens/settings/ChangePasswordScreen.tsx` (Implemented as Configurable Modal in Settings) <!-- id: 7 -->
- [x] Update Navigation <!-- id: 8 -->
    - [x] Register new screens in `RootNavigator.tsx` <!-- id: 9 -->
- [x] Integrate & Cleanup <!-- id: 10 -->
    - [x] Update `ProfileScreen.tsx` to navigate to new screens <!-- id: 11 -->
    - [x] Remove old `OptionGridModal` usage <!-- id: 12 -->
