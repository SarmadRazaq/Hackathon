# Onboarding Overlay Screen Walkthrough

I have built the new onboarding overlay matching the "Apple Set-Up" style specified in your “perfect version” screenshots. 

## What Was Added
- **[NEW] `src/screens/onboarding/HomeOverlayOnboardingScreen.tsx`**

## Key Features Implemented
1. **Premium Background:** Uses Expo's `BlurView` (`dark` tint, `65` intensity) to create that "60-70% dark blur overlay" feel.
2. **Minimal Glowing Dots:** Created a custom `GlowingDot` component containing a solid 8px core matched with a 20px translucent aura (opacity 35%).
3. **Elegant Connector Lines:** Instead of messy or bulky arrows, I utilized `react-native-svg` to draw `Path` elements mapping quadratic bezier curves (`Q`) from the text blocks precisely down to the glowing dots. This perfectly mimics the "thin curved lines" Apple onboarding aesthetic you requested.
4. **Targeted Drop Coordinates:** 
    - Top Center: Habit Health Circle ("Track your progress daily")
    - Middle Center: Checklist ("Complete tasks to build your streak")
    - Bottom Left: Chat Nav Tab ("Get help from Nudge anytime")
    - Bottom Right: Rewards Nav Tab ("Earn XP and stay motivated")
5. **CTA Button Element:** Integrated your existing app `<Button>` component perfectly anchored to the bottom using `"Got it. Let's start Day 1"` as the primary action. 

> [!NOTE]
> Since the mandate was **"do not edit or change any existing screen"**, I have not touched your root navigator or `JourneyDayViewScreen`. Whenever you're ready, this screen is exported and ready to be loaded as a full-screen or modal overlay on top of the home page. 

## Next Steps
You can incorporate this into your flow by:
1. Pushing it onto your navigation stack as a transparent modal presentation (`presentation: 'transparentModal'`).
2. Alternatively, conditionally rendering it inside `JourneyDayViewScreen` as an absolute layer. You may need to tweak the exact pixel values of the `x` and `y` coordinates inside the component depending on device padding/safe-areas.
