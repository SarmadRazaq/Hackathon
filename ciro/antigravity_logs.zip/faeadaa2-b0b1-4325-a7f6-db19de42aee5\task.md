# Rider/Driver App Issues — Investigation & Fixes

## Issue 1: Wallet Only Shows Cancellation Fee
- [x] Identify root cause — card/external ride payments had no rider transaction record
- [x] Fix: Record rider debit transaction in `RideService.ts` `settleRidePayment`
- [ ] Verify fix

## Issue 2 & 5: Rider Rating & Ride Count Not Updating
- [x] Identify root cause — `User.fromJson` only parsed `driverDetails`; backend wrote to `riderDetails`
- [x] Fix: Parse `riderDetails` in `user_model.dart`
- [x] Fix: Show actual rating in `account_screen.dart`
- [x] Fix: Increment `riderDetails.totalTrips` on ride completion in `RideService.ts`
- [ ] Verify fix

## Issue 3: Active Sessions & Login History Empty
- [x] Identify root cause — Google/Apple sign-in didn't call `POST /api/v1/auth/login`
- [x] Fix: Add session recording to `signInWithGoogle` and `signInWithApple` in `auth_service.dart`
- [ ] Verify fix

## Issue 4: Driver App Toggles
- [x] Confirmed toggles are working correctly — no fix needed

## Issue 6: Red Error on Delivery Screen
- [x] Identify root cause — `_buildDeliveryCard` reads flat fields but data is nested
- [x] Fix: Read nested `dropoffLocation.address`, `pricing.estimatedFare`, `pricing.currency`
- [ ] Verify fix
