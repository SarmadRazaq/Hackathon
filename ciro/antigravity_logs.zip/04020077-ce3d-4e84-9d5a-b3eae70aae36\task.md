# Task List

## Active Tasks
- [x] Fix "Provider" Error (AuthService in Login/Security screens)
- [x] Implement "Change Password" (Firebase re-auth + update)
- [x] Implement "Unlock with Face ID" (local_auth + secure storage + splash check)
- [x] Implement "Link Google" (Google Sign-In + Firebase linking)
- [x] Refine "Passkeys" Setup (Prompt for password & save credentials)
- [x] Add "Show/Hide Password" (Eye button) to all password inputs (Driver & Rider)
- [x] Rides Screen Redesign <!-- id: 4 -->
    - [x] Locate current "Rides" screen implementation (`bookings_screen.dart`) <!-- id: 5 -->
    - [x] Update Backend (`driver.controller.ts`) to support `upcoming` vs `history` filtering <!-- id: 6 -->
    - [x] Update Frontend Service & Provider to handle new filter <!-- id: 7 -->
    - [x] Refactor `bookings_screen.dart` to use Tabs (Upcoming / History) <!-- id: 8 -->
    - [x] Implement "Upcoming Ride" card UI <!-- id: 9 -->
    - [x] Refine UI to match mockup (Assets, Colors, Navigation) <!-- id: 11 -->
    - [x] Verify changes (Requires Backend Restart) <!-- id: 10 -->
- [x] Implement Payout History <!-- id: 12 -->
    - [x] Create `seed_payouts.ts` script <!-- id: 13 -->
    - [x] Update Backend Service & Controller (`EarningsService.ts`, `earnings.controller.ts`) <!-- id: 14 -->
    - [x] Update Frontend Model & Service (`EarningsDashboard`, `EarningsService`) <!-- id: 15 -->
    - [x] Update `EarningsScreen` with Payout Summary Card <!-- id: 16 -->
    - [x] Update `PayoutHistoryScreen` UI <!-- id: 17 -->
- [x] Implement Earnings Dashboard Charts <!-- id: 18 -->
    - [x] Create chart data model
    - [x] Implement Daily Earnings Gauge
    - [x] Implement Weekly Bar Chart
    - [x] Implement Monthly Bar Chart
    - [x] Fix `EarningsScreen` layout to prevent "Infinite height" errors
    - [x] Remove `Expanded` widgets from `EarningsScreen` children
    - [x] Ensure `WeeklyBarChart` and `MonthlyBarChart` have bounded height (wrapped in SizedBox)
    - [x] Fix `DailyEarningsGauge` layout (use `MainAxisSize.min`)
    - [x] Address `RenderInputPadding` error (Likely in `PayoutScreen`, added `SingleChildScrollView` & null checks)
    - [x] Fix `Null check operator` crash (Added `dashboard` null check, data sanitization, and robust bank list filtering)
- [x] Verify `EarningsScreen` and `PayoutScreen` render correctly without errors
- [ ] Verify `WeeklyBarChart` and `MonthlyBarChart` display data correctly
- [x] Verify & Fix Earnings Models Integration (Backend + Frontend)
- [ ] Restore Earnings Screen charts (`EarningsScreen.dart`) <!-- id: 23 -->

## Completed Tasks
- [x] Fix syntax error in `home_screen.dart`
- [x] Fix build error in `build.gradle.kts`
- [x] Troubleshoot Doppler CLI error
- [x] Run Electron App
- [x] Debug Layout Errors in Earnings Screen
