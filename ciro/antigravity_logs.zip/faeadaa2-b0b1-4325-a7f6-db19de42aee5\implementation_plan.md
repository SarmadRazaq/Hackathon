# Fix 6 Reported Issues in Rider & Driver Apps

Investigation of 6 issues across rider app, driver app, and backend. Root causes identified; proposed fixes below.

---

## Issue 1: Wallet Only Shows Cancellation Fee

**Root Cause:** When a rider pays via **card/external gateway**, the payment goes through escrow (`recordEscrowDeposit`) which credits the **platform escrow wallet** — no `transactions` record is written for the **rider**. The `getPaymentHistory` endpoint queries `transactions` by `userId`, so only `chargeWalletForRide` (wallet payments) and `cancellation_fee` debits appear. Card-based ride payments are invisible.

**Fix:** In `settleRidePayment()`, after settlement, record a rider-side debit transaction so it shows in wallet history.

### [Component: Backend]

#### [MODIFY] [RideService.ts](file:///F:/BlackLivery/backend/src/services/RideService.ts)

After line ~1100, following the escrow capture or direct settlement, add a `processTransaction` call to record a rider debit:
```diff
+// Record rider-side debit transaction for wallet history visibility
+const riderFare = ride.pricing?.finalFare ?? ride.pricing?.estimatedFare ?? 0;
+if (riderFare > 0 && ride.paymentMethod !== 'wallet') {
+    const currency = (ride.pricing?.currency as 'NGN' | 'USD') || 'NGN';
+    await walletService.processTransaction(
+        ride.riderId,
+        riderFare,
+        'debit',
+        'ride_payment',
+        `Ride payment ${ride.id}`,
+        `RIDER-DEBIT-${ride.id}-${Date.now()}`,
+        {
+            walletCurrency: currency,
+            metadata: { rideId: ride.id, paymentMethod: ride.paymentMethod ?? 'card' }
+        }
+    ).catch(err => logger.warn({ err, rideId: ride.id }, 'Failed to record rider debit transaction'));
+}
```

> [!WARNING]
> This may fail with "Insufficient funds" if the rider's wallet balance is 0 (which it will be for card-only riders). Two options:
> 1. **Skip wallet balance check for history-only debit entries** — requires a new `processTransaction` option like `skipBalanceCheck: true`
> 2. **Write directly to `transactions` collection** without going through the double-entry ledger — simpler, just for display
>
> **Recommendation:** Option 2 (write a display-only record) is safer and avoids disrupting the ledger. Need your input on which approach you prefer.

---

## Issue 2 & 5: Rider Rating & Ride Count Not Updating

**Root Cause:** 
- Backend `updateRiderAverageRating()` writes to `riderDetails.rating` and `riderDetails.totalRatings` 
- Rider `User.fromJson()` only parses `rating`/`totalTrips` from `driverDetails` — riders don't have `driverDetails`
- `account_screen.dart` hardcodes rider rating to `'5.0'`
- Rider `totalTrips` is never incremented by the backend on ride completion

### [Component: Rider App — User Model]

#### [MODIFY] [user_model.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/core/models/user_model.dart)

Parse `riderDetails` in addition to `driverDetails`:
```diff
     if (json['driverDetails'] != null) { ... }
+
+    // Parse rider details (rating, totalTrips) for rider accounts
+    if (json['riderDetails'] != null) {
+      final riderDetails = json['riderDetails'] as Map<String, dynamic>;
+      rating ??= (riderDetails['rating'] is num)
+          ? (riderDetails['rating'] as num).toDouble()
+          : null;
+      totalTrips ??= riderDetails['totalTrips'] as int? ??
+          riderDetails['totalRatings'] as int?;
+    }
+
+    // Fallback: top-level fields
+    rating ??= (json['riderRating'] is num)
+        ? (json['riderRating'] as num).toDouble()
+        : (json['rating'] is num ? (json['rating'] as num).toDouble() : null);
+    totalTrips ??= json['totalTrips'] as int?;
```

### [Component: Rider App — Account Screen]

#### [MODIFY] [account_screen.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/presentation/pages/account_screen.dart)

Replace hardcoded `'5.0'` with actual user rating:
```diff
-  user?.role == 'driver'
-      ? (user?.rating?.toStringAsFixed(1) ?? '5.0')
-      : '5.0',
+  user?.rating?.toStringAsFixed(1) ?? '5.0',
```

### [Component: Backend — Rider Trip Count]

#### [MODIFY] [RideService.ts](file:///F:/BlackLivery/backend/src/services/RideService.ts)

In `handlePostStatusChange` under `case 'completed'`, increment rider's `totalTrips`:
```diff
+// Increment rider's total trips count
+await db.collection('users').doc(ride.riderId).update({
+    'riderDetails.totalTrips': FieldValue.increment(1)
+}).catch(err => logger.warn({ err, riderId: ride.riderId }, 'Failed to increment rider totalTrips'));
```

---

## Issue 3: Active Sessions & Login History Empty

**Root Cause:** The backend correctly records sessions and login history in the `login()` handler. The rider app calls `POST /api/v1/auth/login` after Firebase sign-in (line 97-101 in `auth_service.dart`), but errors are caught silently. If the call fails (e.g., network timeout), no sessions are recorded.

**Likely Scenario:** The call may be succeeding, but the user hasn't logged out and back in since sessions were implemented, so no data exists. Or the call is failing silently.

### [Component: Rider App — Auth Service]

#### [MODIFY] [auth_service.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/core/services/auth_service.dart)

Improve error logging to make silent failures visible:
```diff
         try {
           final dio = ApiClient().dio;
           await dio.post('/api/v1/auth/login', data: {'email': email});
+          debugPrint('=== AuthService.login: Session recorded on backend ===');
         } catch (loginRecordError) {
-          // silent
+          debugPrint('=== AuthService.login: Failed to record session: $loginRecordError ===');
         }
```

> [!IMPORTANT]
> This is likely a data issue — the user needs to log out and log back in to generate sessions. The code path is correct.

---

## Issue 4: Driver App Toggles (Airport and Delivery Rides)

**Finding:** The toggles **ARE working correctly**. The `DriverPreferencesProvider` stores preferences in `SharedPreferences`, and `RideProvider` auto-declines rides based on these preferences. Specifically:
- `acceptDeliveries` → filters out delivery ride requests  
- `airportRides` → filters out airport transfer requests

**No code fix needed.** The issue may be that:
1. The toggle state resets to `true` on fresh install (defaults are all `true`)
2. The driver needs to go to **Preferences** screen to toggle them on
3. No delivery or airport rides are being dispatched in the driver's region

---

## Issue 6: Red Error on Delivery Screen

**Root Cause:** `_buildDeliveryCard()` in `my_rides_screen.dart` reads `delivery['dropoffAddress']` as `String?`, but the backend `getDeliveryHistory` returns full ride documents where the address is nested: `delivery['dropoffLocation']['address']`. The type cast fails at runtime producing a red error.

### [Component: Rider App — My Rides Screen]

#### [MODIFY] [my_rides_screen.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/presentation/pages/my_rides_screen.dart)

Fix address extraction in `_buildDeliveryCard`:
```diff
   Widget _buildDeliveryCard(Map<String, dynamic> delivery) {
     final status = (delivery['status'] ?? delivery['deliveryStatus'] ?? 'pending') as String;
-    final dropoffAddr = delivery['dropoffAddress'] as String? ?? '';
+    // Address may be top-level or nested inside location object
+    final dropoffAddr = delivery['dropoffAddress'] as String?
+        ?? (delivery['dropoffLocation'] is Map
+            ? (delivery['dropoffLocation'] as Map)['address'] as String?
+            : null)
+        ?? '';
     final fare = (delivery['estimatedFare'] ?? delivery['fare'] ?? 0) as num;
-    final currency = delivery['currency'] as String? ?? 'NGN';
+    // Currency may be top-level or nested inside pricing
+    final currency = delivery['currency'] as String?
+        ?? (delivery['pricing'] is Map
+            ? (delivery['pricing'] as Map)['currency'] as String?
+            : null)
+        ?? 'NGN';
     final createdAt = delivery['createdAt'] as String?;
```

Also fix the fare extraction since pricing is nested:
```diff
-    final fare = (delivery['estimatedFare'] ?? delivery['fare'] ?? 0) as num;
+    final fare = (delivery['estimatedFare']
+        ?? delivery['fare']
+        ?? (delivery['pricing'] is Map ? (delivery['pricing'] as Map)['estimatedFare'] : null)
+        ?? 0) as num;
```

---

## Verification Plan

### Manual Verification (Recommended)

Since the apps are already running (`flutter run` for both rider/driver, `npm run dev` for backend):

1. **Issue 6 (Delivery Screen):** After fixing `_buildDeliveryCard`, hot restart the rider app and navigate to **My Rides → Delivery** tab. The red error should be gone.

2. **Issue 2/5 (Rating & Trips):** After fixing `user_model.dart` and `account_screen.dart`, hot restart the rider app and check the **Account** screen. Rating and trip count should reflect actual data (or `5.0` / `0` if no rides yet).

3. **Issue 3 (Sessions):** After fixing error logging, log out of the rider app and log back in. Then navigate to **Account → Login & Security → Active Sessions** and **Login History**. Both should show data.

4. **Issue 1 (Wallet):** After backend fix, complete a test ride with card payment, then check the wallet tab. The ride payment should appear as a transaction.

5. **Issue 4 (Toggles):** In driver app, go to **Preferences** screen, toggle off "Accept Deliveries" and "Airport Rides", then verify no delivery/airport ride offers appear.

> [!IMPORTANT]
> Please let me know:
> 1. For **Issue 1**, do you prefer I write a display-only transaction record (simpler, no ledger impact) or add a `skipBalanceCheck` option to `processTransaction`?
> 2. For **Issue 3**, have you tried logging out and back in recently? The data may simply not exist yet.
> 3. For **Issue 4**, can you confirm what exactly you're not seeing? The toggles control which ride offers auto-decline — they don't create rides.
