# SWE-bench Implementation Tasks

- `[x]` **Component 1**: Create `swebench_dataset.py` — HuggingFace dataset fetcher + cache
- `[x]` **Component 2**: Create `swebench_repo_setup.py` — git clone, checkout, patch, diff
- `[x]` **Component 3**: Create `swebench_scorer.py` — FAIL_TO_PASS / PASS_TO_PASS scoring
- `[x]` **Component 4**: Modify `executor.py` — add `run_shell_command`, `run_tests`, configurable tool budget
- `[x]` **Component 5**: Modify `swebench_runner.py` — wire all new components
- `[x]` **Component 6**: Create `run_swebench.py` — clean CLI entry point
- `[x]` **Verify**: All self-tests pass; dry-run fetches 300 instances cleanly
