# Implementation Plan: Google Cloud Enterprise Upgrade

This plan details the massive architectural shift required to upgrade CIRO from a prototype to a full Google Cloud Platform (GCP) enterprise application, fully utilizing your GCP credits.

## Proposed Changes

### 1. AI & Machine Learning (Vertex AI, TTS, STT)
#### [MODIFY] backend/requirements.txt
- Add `google-cloud-aiplatform` (Vertex AI).
- Add `google-cloud-texttospeech` and `google-cloud-speech`.

#### [MODIFY] backend/agents/orchestrator.py
- Update the LLM configuration to use Vertex AI instead of Google AI Studio. This involves passing the correct Vertex initialization parameters to the ADK `LlmAgent` or setting the environment variables for `google.genai` to route traffic through your GCP project.

#### [MODIFY] backend/main.py
- **TTS Endpoint**: Create a new `POST /api/tts` endpoint. It will take the generated "Public Alert" text, send it to Google Cloud Text-to-Speech, and return a base64 encoded MP3 audio file.
- **STT Endpoint**: Fully implement the `POST /api/transcribe` endpoint using Google Cloud Speech-to-Text to handle citizen voice notes.

#### [MODIFY] mobile/src/screens/ResultScreen.tsx
- Replace `expo-speech` with an `expo-av` audio player that fetches the studio-quality MP3 from our new `/api/tts` backend endpoint.

### 2. Maps & Geospatial Data (Google Maps Platform)
#### [MODIFY] backend/agents/tools.py
- **Geocoding**: Replace the TomTom Geocoding API with the Google Maps Geocoding API (`https://maps.googleapis.com/maps/api/geocode/json`).
- **Traffic**: Replace the TomTom Traffic Flow API with the Google Maps Routes API. We will calculate a route through the affected area with `routingPreference=TRAFFIC_AWARE` to extract the congestion metrics.

### 3. Database & Storage (Firestore & GCS)
#### [MODIFY] backend/requirements.txt
- Add `google-cloud-storage`.

#### [MODIFY] backend/main.py
- **Image Upload**: When a citizen submits an image, the backend will decode the base64 string, upload it to a Google Cloud Storage (GCS) bucket, and pass the secure `gs://` URI to the Multimodal Ingestor Agent, rather than passing massive base64 strings in memory.

### 4. Deployment (Cloud Run & Firebase Hosting)
- **Cloud Run**: You already have the `Dockerfile`. You will just run the deployment command.
- **Firebase Hosting**: I will provide you with a `firebase.json` configuration file to deploy your `backend/static/index.html` Command Center dashboard to Firebase's global CDN.

---

## User Review Required

> [!WARNING]
> This is a major architectural overhaul. Before I begin writing the code, please ensure you have enabled the following APIs in your Google Cloud Console:
> 1. Vertex AI API
> 2. Cloud Text-to-Speech API
> 3. Cloud Speech-to-Text API
> 4. Google Maps Geocoding API & Routes API
> 5. Cloud Storage API
>
> You will also need to provide your backend with a `GOOGLE_APPLICATION_CREDENTIALS` service account JSON file, or run `gcloud auth application-default login` on your local machine so the backend can securely authenticate with these GCP services.
>
> **Do you want me to proceed with these code changes?**
