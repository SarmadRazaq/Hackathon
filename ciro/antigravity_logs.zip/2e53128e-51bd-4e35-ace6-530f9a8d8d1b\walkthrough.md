# Root Cause: Fusion IL Weaver (CodeGen) is Missing

## The Error

```
InvalidOperationException: Type TestNetwork has not been weaved.
Has the assembly Assembly-CSharp been added
```

This error occurs for **any** script that extends `NetworkBehaviour` — not just `TestNetwork`. The weaver is supposed to run automatically during compilation via Unity's ILPostProcessor pipeline, but it can't run because the code that implements it is gone.

## Root Cause: Missing `Assets/Photon/Fusion/CodeGen/` Directory

The entire **CodeGen directory is missing** from your Fusion installation. This directory should contain:

| File | Purpose |
|------|---------|
| `Fusion.CodeGen.cs` | The ILPostProcessor that weaves `NetworkBehaviour` subclasses |
| `Fusion.CodeGen.User.cs` | User-facing hooks for the weaver |
| `Fusion.CodeGen.asmdef` | Assembly definition that registers the ILPostProcessor with Unity |

Evidence:
- The project has a stale `Unity.Fusion.CodeGen.csproj` at the root referencing these files, confirming they **used to exist**
- The `NetworkProjectConfig.fusion` is correctly configured with `"AssembliesToWeave": ["Fusion.Unity", "Assembly-CSharp"]`
- The `FusionWeaverTriggerImporter.cs` is present and correct
- No `.fusionweavertrigger` asset file exists (it would have been created by the CodeGen asmdef)

> [!CAUTION]
> Without the CodeGen directory, the Fusion weaver literally does not exist in your project. Running "Tools → Fusion → Run Weaver" only triggers a recompile, but there's no ILPostProcessor to process the assemblies during that recompile.

## What's Working vs. What's Broken

| Component | Status | Notes |
|-----------|--------|-------|
| `NetworkProjectConfig.fusion` | ✅ Correct | Lists `Assembly-CSharp` in `AssembliesToWeave` |
| `FusionWeaverTriggerImporter.cs` | ✅ Present | Triggers recompile when config changes |
| `ILWeaverUtils.cs` | ✅ Present | Menu item "Run Weaver" works |
| `Fusion.Runtime.dll` | ✅ Present | Contains `NetworkBehaviour`, `NetworkObject`, etc. |
| **`Fusion.CodeGen/` directory** | ❌ **MISSING** | **The actual weaver code is gone** |

## Fix: Re-import the Fusion SDK

This is **not fixable by editing scripts** — the missing files are proprietary Photon Fusion code. You need to restore the CodeGen folder:

### Option A: Re-import from Photon SDK (Recommended)
1. Download the **Photon Fusion 2 SDK** from the [Photon Dashboard](https://dashboard.photonengine.com/) or the Unity Asset Store
2. Before importing, **back up** your current `Assets/Photon/Fusion/Resources/` folder (to preserve your `NetworkProjectConfig.fusion` and `PhotonAppSettings.asset`)
3. Import the SDK — focus on ensuring the `Assets/Photon/Fusion/CodeGen/` folder gets imported
4. Restore your backed-up config files
5. In Unity: **Tools → Fusion → Run Weaver** (or just let it recompile)

### Option B: Selective Import
1. Open the Fusion SDK `.unitypackage`
2. Deselect everything
3. Select **only** the `Assets/Photon/Fusion/CodeGen/` folder
4. Import
5. Unity will recompile and the weaver should now run

### After Re-importing
- The error should disappear on the next compilation
- Any `NetworkBehaviour` subclass (including your `TestNetwork`) will be weaved automatically
- You do NOT need to change any of your existing scripts — they're all correct

## Why Your Existing Scripts Still Work (Partially)

Your current networking scripts (`PlayerNetwork`, `PlayerNetworkSetup`, `NetworkManager`, `NetworkPlayerFix`) all extend `MonoBehaviour`, **not** `NetworkBehaviour`. They interact with Fusion through:
- `NetworkObject` (a component on the prefab, weaved as part of `Fusion.Unity` assembly)
- `NetworkTransform` (same)
- `INetworkRunnerCallbacks` (an interface, no weaving needed)
- `INetworkInput` struct with `[NetworkInputWeaved(9)]` attribute (manually annotated)

This is why the existing multiplayer setup works — none of your scripts actually need to be weaved. The error only appears when you create a **new** script extending `NetworkBehaviour`.
