# Add Proper Atlas Sprites to All UI Screens

The current UI uses `Sprite.Create()` at runtime to extract regions from Atlas1 and Atlas2, but only a handful of sprites are defined (8 from Atlas1, 7 from Atlas2). Many UI elements — panels, icons, progress bars, buttons, the main card frame, dice, star icons, chevrons, building icons, etc. — are still flat-colored rectangles instead of using the rich pre-designed art from the atlases.

## User Review Required

> [!IMPORTANT]
> The atlas textures are currently imported as **Default** type with `isReadable: false`. The code uses `Sprite.Create()` at runtime which requires `isReadable: true` and `textureType: 8` (Sprite). These meta files must be updated or Unity will throw errors when trying to read pixel data.

> [!WARNING]
> The sprite rects below are **estimated from visual inspection** of the atlas images. If any crop looks off in Unity, the `RectFromTopLeft()` coordinates will need fine-tuning. The approach is conservative — we're adding many new sprite extractions but using the same proven `AddAtlasSprite` + `TryApplyNamedSprite` pattern already in use.

## Proposed Changes

### Texture Import Settings

#### [MODIFY] [Atlas1.png.meta](file:///f:/Git/monopoly-unity/monopoly/Assets/Resources/BigSpender/UI/Atlas1.png.meta)
- Set `isReadable: 1` (was `0`) — required for `Sprite.Create()`
- Set `textureType: 8` (Sprite) — was `0` (Default)
- Set `alphaIsTransparency: 1` — proper alpha handling for UI sprites
- Set `spriteMode: 1` (Single) — marks it as a sprite texture
- Set `enableMipMap: 0` — not needed for UI, saves memory

#### [MODIFY] [Atlas2.png.meta](file:///f:/Git/monopoly-unity/monopoly/Assets/Resources/BigSpender/UI/Atlas2.png.meta)
- Same changes as Atlas1

---

### Core Script Changes

#### [MODIFY] [BigSpenderMockupUiDirector.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/BigSpenderMockupUiDirector.cs)

**1. Expand `LoadDesignSprites()` — Add ~20 new sprite extractions from both atlases:**

From **Atlas1** (the one with Victory text, menu buttons, blue bars, icons):
| Sprite Key | Description | Approx Region (x, y, w, h from top-left) |
|---|---|---|
| `BlueBarLarge` | Wide blue header bar (top-left) | (27, 44, 548, 47) |
| `BlueBarMedium` | Medium blue bar | (27, 107, 548, 40) |
| `BlueBarSmall` | Short blue bar | (27, 162, 362, 36) |
| `FolderPanel` | Dark blue folder/panel frame (center-top) | (574, 70, 351, 203) — already `HudFrame` |
| `HomeIcon` | House/home icon with minus | (528, 360, 90, 90) |
| `CheckmarkIcon` | Green glowing checkmark | (640, 330, 140, 140) |
| `MenuButtonGold` | Gold "Return to Menu" large | (27, 563, 329, 92) — already `MenuButton` |
| `MenuButtonGoldSmall` | Gold button smaller variant | (373, 563, 287, 72) |
| `MenuButtonSilver` | Silver/grey button | (678, 563, 256, 72) |
| `MenuButtonGoldAlt` | Row 2 gold button | (27, 668, 329, 92) |
| `GoldOval` | Gold oval/ellipse shape | (960, 567, 184, 112) |
| `CoinBullet` | Small gold coin (right side) | (1168, 572, 68, 80) |

From **Atlas2** (the one with Roll button, BUY/IMPROVE/SELL buttons, dice, building, stars):
| Sprite Key | Description | Approx Region (x, y, w, h from top-left) |
|---|---|---|
| `PropertyPanel` | Large dark blue panel with gold border (center) | (482, 66, 470, 408) |
| `DtaProgressBar` | DTA progress bar (bottom of panel) | (520, 442, 392, 34) |
| `GreenBarShort` | Short green bar | (210, 340, 268, 46) |
| `DarkBlueBar` | Dark navy bar | (210, 404, 268, 36) |
| `DiceGold` | Gold dice (near roll button) | (710, 528, 82, 82) |
| `DiceGoldSmall` | Smaller gold dice (right side) | (866, 572, 62, 62) |
| `ChevronRight` | Gold chevron arrows `>>` | (920, 555, 60, 60) |
| `ChevronLeft` | Gold chevron arrows `<<` | (420, 590, 60, 60) |
| `BuildingIcon` | 3D building/apartment icon | (30, 520, 140, 180) |
| `StarGold` | Yellow filled star | (200, 530, 48, 48) |
| `StarGrey` | Grey empty star | (250, 530, 48, 48) |
| `CarIcon` | Small car icon | (304, 540, 42, 42) |
| `HouseIconSmall` | Small house icon (yellow) | (350, 530, 48, 48) |
| `HouseIconLarge` | Larger house icon | (400, 530, 52, 52) |
| `LightningIcon` | Lightning bolt icon | (220, 588, 36, 44) |
| `LockIcon` | Padlock icon | (264, 590, 36, 44) |
| `BuyButtonInactive` | Wider buy button variant | (1208, 90, 174, 76) |
| `ImproveButtonInactive` | Wider improve button | (1208, 193, 154, 58) |
| `SellButtonBlue` | Blue "Sell to Bank" button | (1021, 279, 174, 59) — already `SellButton` |
| `SellButtonBlueSmall` | Small blue sell button | (1208, 279, 148, 59) |
| `SellButtonGrey` | Disabled grey sell button | (1021, 358, 174, 52) |
| `SellButtonGreySmall` | Small grey sell button | (1208, 358, 148, 52) |
| `CoinTrail` | Animated coin with sparkle trail | (340, 650, 200, 80) |
| `PigIconSmall` | Small piggy bank + safe composite | (30, 340, 165, 130) |
| `SafeIconSmall` | Safe icon (smaller, Atlas2) | (200, 255, 100, 100) |

**2. Apply sprites to existing screen builds:**

- **`BuildPropertyUpgradeScreen()`**: Apply `PropertyPanel` sprite to the card background, `BuyButton` to buy, `SellButton`/`SellButtonBlue` to sell, `ImproveButton` to protect
- **`BuildMainBoardScreen()`**: Apply `DiceGold` near the roll result text, `CoinBullet` as decorative elements, `RollButton` to the roll dice button
- **`BuildDtaDashboardScreen()`**: Apply `DtaProgressBar` to the progress bar frame, `SafeIconSmall`+`PigIconSmall` as icon decorations, `CoinTrail` on recent feed header
- **`BuildSafeCrackerScreen()`**: `SafeIcon` already applied — add `CoinBullet` for cash cells and `LockIcon` for locked/unrevealed cells
- **`BuildCourthouseScreen()`**: Add `StarGold`/`StarGrey` for strength indicators
- **`BuildLandscapeBoardScreen()`**: Apply `DiceGold` near dice display, `ChevronLeft`/`ChevronRight` near navigation
- **`BuildMobileScreen()`**: Apply `InventoryPanel` sprite to inventory area
- **`BuildWinStateScreen()`**: Already has `VictoryTitle`/`VictoryMilestone`/`VictoryComplete` — add `GoldOval` as confetti/medal background, `CheckmarkIcon` on win conditions
- **`BuildPassAndPlayScreen()`**: Add `ChevronRight` between player name labels
- **`BuildParadiseCastawayScreen()`**: Add `StarGold` for paradise, `LightningIcon` for castaway

**3. Apply sprites to `LaunchHudController.cs` HUD elements:**

#### [MODIFY] [LaunchHudController.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/LaunchHudController.cs)
- Load sprite library from `BigSpender/UI` resources (same pattern as BigSpenderMockupUiDirector)
- Replace the flat-colored `$` badge icon with `CoinIcon` sprite from Atlas1
- Replace the flat-colored `A` badge icon with `SafeIcon` sprite from Atlas1
- Apply `BlueBarLarge` sprite to the header panel trim
- Apply `RollButton` sprite from Atlas2 to the roll button in the action dock
- Apply `BuyButton`/`ImproveButton`/`SellButton` sprites to corresponding buttons
- Apply `FolderPanel` (HudFrame) sprite to the header panel background

**4. Apply sprites to `TryApplyButtonSprite()` — enhance matching:**
- Add patterns for `donate`, `spin`, `gavel`, `collect`, `accept`, `start`, `play again`, `view stats`
- Map "DONATE" → `BuyButton` sprite (green/gold button)
- Map "SPIN"/"GAVEL"/"START"/"PLAY AGAIN" → `MenuButtonGold` or `RollButton`

## Open Questions

> [!IMPORTANT]
> The exact pixel coordinates for sprite rects are estimated from visual inspection. After applying, some may need 5-20px adjustments if the crop is not pixel-perfect. Would you like me to use more conservative (slightly larger) rects to ensure no clipping, or precise ones that may need tweaking?

## Verification Plan

### Manual Verification
1. Open Unity, let it reimport Atlas1/Atlas2 with new meta settings
2. Enter Play mode — expect no `Texture is not readable` errors in console
3. Press F1 to open Gallery, cycle through all 13 mockup screens
4. Verify sprites appear on buttons, panels, icons, progress bars
5. Check the in-game HUD (LaunchHudController) for sprite-based buttons and badges
