# Implementation Plan — CIRO Multi-Crisis Orchestration Live Integration

This plan details the steps to transition the CIRO (Crisis Intelligence & Response Orchestrator) platform from mock/canned data to a live, end-to-end integrated agentic platform. It covers backend extensions (Antigravity wrapper, multi-crisis coordination, verifier agent, NASA/PMD/NDMA tools, loss aggregator, baseline comparison) and frontend wiring (admin panel and mobile app).

---

## User Review Required

> [!IMPORTANT]
> **API Key Requirements**: The NASA FIRMS (hotspot detection), PMD, and NDMA data feeds will have synthetic fallbacks to ensure robust operation when live endpoints are rate-limited or require credentials in a hackathon setting.
> We will expose a simplified mock database in memory to handle state synchronously during the demo, while integrating firebase push notification alerts in real-time.

---

## Open Questions

> [!NOTE]
> None. We will proceed with implementing all requested integrations as specified.

---

## Proposed Changes

### Layer A — Backend (FastAPI + Google ADK + Antigravity Runtime)

#### [NEW] [antigravity_runtime.py](file:///f:/Hackathon/ciro/backend/antigravity_runtime.py)
- Create a runtime wrapper class `AntigravityRuntime` to act as the execution safety and validation supervisor.
- Integrates the Google ADK runner pipeline.
- Performs guardrail checks (safety validation, hallucination checking, schema conformance) before returning agent output.

#### [NEW] [multi_coordinator.py](file:///f:/Hackathon/ciro/backend/agents/multi_coordinator.py)
- Implement `MultiCrisisCoordinator` to manage concurrent executions of the agent pipeline for multiple active incidents.
- Integrates resource negotiation between pipelines using a shared lock and shared `resource_pool` state.
- Resolves conflicts programmatically via the negotiator agents.

#### [MODIFY] [tools.py](file:///f:/Hackathon/ciro/backend/agents/tools.py)
- Implement `get_nasa_firms_hotspots(bbox)`: Free NASA FIRMS hotspot coordinate query, returning fire pixel coordinates.
- Implement `get_pmd_weather(city)`: Fallbacks gracefully to Open-Meteo, labeling data as "LIVE - PMD" when active.
- Implement `get_ndma_alerts(region)`: Scraping or API bulletin mock for NDMA alerts.
- Implement `aggregate_impact_losses(severity, crisis_type)`: Analytical module for traffic, logistical, economic, and environmental losses.

#### [NEW] [rule_based.py](file:///f:/Hackathon/ciro/backend/baseline/rule_based.py)
- Implement baseline deterministic engine: matching keyword thresholds, pre-calculated response templates, and static severity mappings.

#### [MODIFY] [main.py](file:///f:/Hackathon/ciro/backend/main.py)
- Expose the new live endpoints:
  - `POST /api/analyze/multi` - Orchestrate multiple crises concurrently
  - `POST /api/reports/verify` - Call citizen report verifier agent
  - `GET /api/baseline/score` - Run rule-based baseline comparison
  - `GET /api/logs/export` - Export session trace logs
  - Live state updates using polling / Firestore sync helpers

---

### Layer B — Admin Panel (React / Next.js)

#### [MODIFY] [AppShell.tsx](file:///f:/Hackathon/ciro/admin_panel/src/components/layout/AppShell.tsx)
- Connect context state to fetch live data from `/api/crises/active`, `/api/resources/pool`, and `/api/analytics` instead of `DEMO_CRISES` static variables.
- Add live update handlers.

#### [MODIFY] [comparison/page.tsx](file:///f:/Hackathon/ciro/admin_panel/src/app/comparison/page.tsx)
- Replace hardcoded charts and stats with calls to `/api/baseline/score` and live agent outputs.

#### [MODIFY] [map/page.tsx](file:///f:/Hackathon/ciro/admin_panel/src/app/map/page.tsx)
- Ensure multiple active incident markers are rendered dynamically with color coding based on active crises in state.

---

### Layer C — Mobile App (React Native / Expo)

#### [MODIFY] [HomeScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/HomeScreen.tsx)
- Wire sidebar navigation drawer using standard layouts.
- Render "Active Crises" tile for dispatcher view using live backend endpoint.

#### [MODIFY] [ResultScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/ResultScreen.tsx)
- Add "Before → After" widget for the simulation routing display.

---

## Verification Plan

### Automated Tests
- Run `pytest` if available or hit FastAPI endpoints using test scripts to verify `multi`, `verify`, and `baseline` endpoints.
- Validate that the admin panel builds clean with `npm run build` after integration.

### Manual Verification
- Trigger test scenario injection from `/settings` page and watch Command Center, Map, and Resource pools update dynamically.
