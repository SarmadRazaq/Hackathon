# CIRO Production Integration Implementation Plan

This plan outlines the complete migration of the CIRO crisis response platform from its current hybrid mock/partial state to a fully-wired, production-ready live system. This implements the 5-phase migration roadmap for backend orchestration, multi-agent validation, and frontend dashboards (admin panel and mobile app).

---

## User Review Required

Please review the following items before we begin execution:

> [!WARNING]
> **Firebase Credentials Migration**
> The current mobile and admin panel applications hardcode coordinates and project settings pointing to `portfolio-website-cd2c6`. Since we do not have direct access to your private CIRO Firebase console, we will create clean configuration mappings and configure a test/fallback emulator state. You will need to supply the final credentials for production deployment.

> [!IMPORTANT]
> **External API Verification**
> The backend tools in `backend/agents/tools.py` utilize Google Maps Platform API, NASA FIRMS API, and Open-Meteo API. The Google Maps API key currently configured in the backend `.env` is: `AIzaSyAdoAZKOyWNl3dt-m-oIbAHu-ZCy1HKuDc`. We will ensure the mobile app uses the configured environment key rather than placeholders.

---

## Open Questions

> [!NOTE]
> 1. **Firebase Authentication Bypass in Development:** Is it acceptable to use the existing `AUTH_DISABLED=true` option for testing the mobile SSE stream locally, or should we verify user registration flows? We propose keeping authentication disabled or using a mock session token for local simulation to ensure smooth end-to-end execution.
> 2. **Mobile App Navigation Setup:** Should the new mobile screens (Resources, Impact, Comms, Action Plan) be added to the main Tab Navigator as separate tabs, or should they be accessed as sub-screens/sub-tabs from the `ResultScreen`? We recommend accessing them as sub-screens/sub-tabs for clean mobile ergonomics.

---

## Proposed Changes

We group the implementation into components corresponding to each roadmap phase.

### Phase 0: Infrastructure Setup

#### [MODIFY] [mobile/.env](file:///f:/Hackathon/ciro/mobile/.env)
- Update Firebase configurations and add `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY`.

#### [NEW] [backend/scripts/seed_firestore.py](file:///f:/Hackathon/ciro/backend/scripts/seed_firestore.py)
- Create a Python script to seed citizen reports, sensors, and active crisis incidents in Firestore for testing the pipeline under realistic mock workloads.

---

### Phase 1: Backend Foundation

#### [MODIFY] [backend/antigravity_runtime.py](file:///f:/Hackathon/ciro/backend/antigravity_runtime.py)
- Integrate the `AntigravityOrchestrator` verification layer:
  - **Confidence threshold validation**: Flag results requiring manual review when confidence is < 50%.
  - **Severity escalation checks**: Ensure critical crises request appropriate minimum resources.
  - **Hallucination verification**: Validate that all tools listed in the agent's reasoning are actual registered tools.

#### [MODIFY] [backend/agents/multi_coordinator.py](file:///f:/Hackathon/ciro/backend/agents/multi_coordinator.py)
- Improve cumulative resource tracking across all running pipelines and verify conflict arbitration logic.
- Ensure the negotiator agent updates Firestore with real-time arbitration decisions.

#### [MODIFY] [backend/main.py](file:///f:/Hackathon/ciro/backend/main.py)
- Wire up Firestore synchronization: save finalized reports, updates, and safety-verified actions to collections.
- Correct SSE broadcast mapping to output both trace-level events and final verification structures cleanly.

---

### Phase 2: Backend Feature Completeness

#### [NEW] [backend/agents/verifier.py](file:///f:/Hackathon/ciro/backend/agents/verifier.py)
- Implement `CitizenReportVerifier` LlmAgent (using Google GenAI ADK or standard SDK).
- Integrate it as an intake validation step before executing the main 8-agent response sequence.
- Ground reports by comparing coordinates against live/synthetic sensor telemetry.

#### [MODIFY] [backend/main.py](file:///f:/Hackathon/ciro/backend/main.py)
- Add `/api/logs/export` endpoint returning a serialized JSON of the entire agent execution trace for auditing.
- Expose `/api/impact/{crisis_id}` using the structured analytical loss model.

---

### Phase 3: Admin Panel UI Alignment

#### [MODIFY] [admin_panel/src/app/comparison/page.tsx](file:///f:/Hackathon/ciro/admin_panel/src/app/comparison/page.tsx)
- Connect rule-based vs AI-agent comparisons to the live `/api/comparison/{crisis_id}` backend endpoint instead of rendering static frontend objects.

#### [MODIFY] [admin_panel/src/app/impact/page.tsx](file:///f:/Hackathon/ciro/admin_panel/src/app/impact/page.tsx)
- Wire the impact simulation view to read calculations from the backend `/api/impact/{crisis_id}` endpoint.

---

### Phase 4: Mobile App Feature Parity

#### [NEW] [mobile/src/screens/ResourcesScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/ResourcesScreen.tsx)
- Create a dashboard displaying the current global resource pool utilization, pending/granted allocations, and negotiator agent decisions.

#### [NEW] [mobile/src/screens/ImpactScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/ImpactScreen.tsx)
- Build a visual multi-domain impact screen mapping economic, logistics, and traffic losses.

#### [NEW] [mobile/src/screens/CommsScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/CommsScreen.tsx)
- Design a view showing the bilingual notifications prepared for various stakeholder groups.

#### [NEW] [mobile/src/screens/ActionPlanScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/ActionPlanScreen.tsx)
- Render the step-by-step action plan timeline, forecast timelines, and evolution metrics.

#### [MODIFY] [mobile/src/navigation/AppNavigator.tsx](file:///f:/Hackathon/ciro/mobile/src/navigation/AppNavigator.tsx)
- Register the new sub-screens inside the mobile stack navigator.

---

## Verification Plan

### Automated Tests
1. **Pipeline Execution Integrity**: Run `/api/analyze/stream` using curl/postman and check for correct SSE format.
2. **Conflict Resolution Validation**: Trigger `/api/analyze/multi` with overlapping sectors and confirm resource re-allocation and negotiation events are yielded.
3. **Safety Layer Checks**: Query validation logic with low-confidence mock inputs to verify they are flagged as `requires_review`.

### Manual Verification
1. **Admin Panel Validation**: Open the Admin Panel, select Comparison & Impact modules, and verify live data updates instead of mocks.
2. **Mobile App Walkthrough**: Start the Expo web server (`npx expo start --web`), navigate through the newly added screens, and verify that actual backend metrics load correctly.
