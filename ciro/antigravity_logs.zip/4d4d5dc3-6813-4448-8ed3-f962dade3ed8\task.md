# Atlas Sprite Integration Tasks

- `[x]` Fix Atlas1.png.meta import settings
- `[x]` Fix Atlas2.png.meta import settings
- `[x]` Expand LoadDesignSprites() with ~40 new sprite extractions
- `[x]` Apply sprites to BuildPropertyUpgradeScreen()
- `[x]` Apply sprites to BuildMainBoardScreen()
- `[x]` Apply sprites to BuildDtaDashboardScreen()
- `[x]` Apply sprites to BuildSafeCrackerScreen()
- `[x]` Apply sprites to BuildCourthouseScreen()
- `[x]` Apply sprites to BuildLandscapeBoardScreen()
- `[x]` Apply sprites to BuildMobileScreen()
- `[x]` Apply sprites to BuildWinStateScreen()
- `[x]` Apply sprites to BuildPassAndPlayScreen()
- `[x]` Apply sprites to BuildParadiseCastawayScreen()
- `[x]` Apply sprites to BuildTravelWheelScreen()
- `[x]` Apply sprites to BuildSkidRowScreen() (via TryApplyButtonSprite matching)
- `[x]` Enhance TryApplyButtonSprite() matching (12 patterns, up from 5)
- `[x]` Add sprite support to LaunchHudController.cs
