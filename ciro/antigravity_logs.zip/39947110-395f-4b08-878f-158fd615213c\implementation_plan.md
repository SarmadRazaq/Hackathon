# Implementation Plan: Project Imagery & Routing Fix

You've requested to fix the 404 error on the dynamic pages and to generate/embed attractive premium images for each of the 7 projects.

## Open Questions
> [!IMPORTANT]  
> The 404 issue is caused by a Next.js 15 breaking change: `params` are now asynchronous. When the code checks for the project slug synchronously, it fails and triggers a 404. I will fix this immediately.
> 
> Regarding the images: I will use my AI image generation capabilities to create 7 distinct, dark-mode, premium UI mockups corresponding to each project (Tennis app, Fitness dashboard, SaaS dashboard, etc.). Do you want these images to look like realistic app screenshots, or more abstract/stylized architectural blueprints?

## Proposed Changes

### 1. Fix the Next.js 15 404 Bug
#### [MODIFY] `src/app/projects/[slug]/page.tsx`
- Refactor the page component to `async` and `await params`. This will resolve the `notFound()` error and properly load the LifeLine project (and all others).

### 2. Generate and Integrate Project Images
#### [NEW] `public/projects/*.png`
- Generate 7 premium UI images using the image generation tool.
- Save them directly into the Next.js `public` directory so they can be served instantly.

### 3. Update Data Model
#### [MODIFY] `src/data/projects.ts`
- Add an `image: '/projects/[id].png'` field to all 7 projects.

### 4. Update UI to Render Images
#### [MODIFY] `src/app/page.tsx`
- Replace the gray placeholder boxes in the project grid with fully responsive `<img />` tags rendering the new project mockups.
#### [MODIFY] `src/app/projects/[slug]/page.tsx`
- Add a massive, beautiful hero image section at the top of the Case Study page to display the generated UI mockup.

## Verification Plan
1. Ensure `npm run dev` hot-reloads and the 404 error disappears.
2. Verify the 7 AI-generated images load correctly on both the homepage grid and the individual case study pages.
