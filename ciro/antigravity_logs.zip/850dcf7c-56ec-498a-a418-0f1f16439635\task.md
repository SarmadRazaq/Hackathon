# Milestone 1 Phase 1 — Task Tracker

## Component 1: Central Game Configuration
- [x] Create `GameConfig.cs` ScriptableObject

## Component 2: Bug Fixes & Consolidation
- [x] Consolidate `GameManager.SellPropertyToBank()` → delegate to `PropertyManager`
- [x] Remove dead code: `ApplyTileInteraction()`, `HandlePropertyTileInteraction()`
- [x] Wire `GameConfig` into `GameManager`
- [x] Wire `GameConfig` into `PropertyManager`
- [x] Wire `GameConfig` into `WinManager`
- [x] Wire `GameConfig` into `EconomyManager`
- [x] Wire `GameConfig` into `PlayerProfile`
- [x] Update `Tile.GetWholesaleValue()` to accept optional multiplier

## Component 3: Compile Fix
- [x] Fix `FindObjectsByType` calls in `ProductionVisualTheme.cs`

## Component 4: Solo Player Auto-Spawn
- [x] Auto-spawn 1 player capsule if none exist in GameManager.Start()
