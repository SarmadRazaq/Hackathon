# Home Onboarding Overlay Screen Implementation Plan

## Goal Description
Implement a new, clean "Apple-style" onboarding overlay screen for the main dashboard ("Home" / Day View). The user has provided an exact layout with 4 callouts (Habit Health Circle, Checklist, Chat, and Rewards) overlaid on a darkened, blurred background, with a "Got it. Let's start Day 1" Call-To-Action.

The instructions say to **create new screens without editing any existing screens**.

> [!WARNING]
> **Clarification Needed on Flow vs. Single Screen**
> 
> Your text mentioned: *"User should be able to click through the 3 screens easily. Screen one describes the home page parts... Then the next one points to the coach nudge feature... Next page points to the next two features"*.
> 
> However, your screenshot instructions explicitly say **"PERFECT VERSION (what your dev should build)"** and **"4 CALLOUTS ONLY (CRITICAL) DO NOT ADD MORE"** on a *single* screen layout.
> 
> For this plan, **I am prioritizing the single-screen "PERFECT VERSION"** described in the screenshot, as it specifically says "what your dev should build". 
> If you'd prefer the segmented click-through flow instead of the single "4 Callouts" overlay, please let me know when approving this plan and I'll adjust it.


## Proposed Changes

### Screens Area

#### [NEW] [HomeOverlayOnboardingScreen.tsx](file:///f:/Git/Unhabit/src/screens/onboarding/HomeOverlayOnboardingScreen.tsx)
Create a React Native functional component that acts as a full-screen absolute overlay. 
- **Backdrop:** A dark semi-transparent view (`rgba(0,0,0,0.65)`) with `blurType="dark"` if `expo-blur` is available, or simply standard opacity.
- **Callouts Structure:** Uses absolute positioning to place "Soft glowing dots" at the exact coordinates of the underlying layout sections (Progress Ring, Tasks List, Chat Tab, Rewards Tab).
- **Aesthetic Additions:** 
  - Dots will have a subtle shadow/glow effect.
  - Thin, elegant curved lines (using pure CSS border-curve illusions or SVG) pointing from text to the glowing dots.
  - Short one-line descriptions styling (`TYPOGRAPHY.fontSize.sm`, `COLORS.textSecondary`).
- **CTA:** "Got it. Let's start Day 1" button anchored at the bottom-center (`position: 'absolute', bottom: 120`).

Since I am instructed **not to modify existing screens**, this component will be ready to drop into a navigator or root component whenever you choose to wire it up.

## Open Questions

1. **SVG Support:** Does this project use `react-native-svg`? If not, drawing curved lines is difficult natively, and I will use elegant angled views or straight minimal directional indicators instead.
2. **Animation:** Would you like a smooth fade-in animation for the callouts, or should they appear statically?
3. **Screen vs Flow:** As noted above, please confirm you are okay with the single 4-callout overlay rather than the 3-step sequence.

## Verification Plan

### Automated Tests
- TypeScript compilation to ensure it builds correctly.

### Manual Verification
- You will be able to temporarily mount this overlay visually or register it in your Navigator to confirm the design perfectly matches the "Calm, premium, subtle" Apple onboarding vision before we integrate its control state.
