# Walkthrough - Fixing Onboarding 400 Error

I have resolved the 400 "No valid fields to update" error that occurred when saving emergency contacts during onboarding.

## Changes Made

### Backend Update
Updated the `IEmergencyContact` model in `User.ts` to include the `relationship` field, matching the data collected in the mobile app.

### Flutter Driver App Update
Aligned the `DriverService` with the backend's expected schema:
- Changed the field name from `phone` to `phoneNumber`.
- Updated the structure to send `emergencyContacts` as an array (plural) instead of a single object (singular).
- Mapped the UI data correctly to the backend fields.

## Verification Results

### Manual Verification
- Verified that the request payload now matches the backend's `allowedFields` list in `auth.controller.ts`.
- The backend `updateProfile` function now correctly identifies the `emergencyContacts` field and performs the database update.

![Emergency Contacts Screen](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/assets/images/screen-5-car.png)

> [!NOTE]
> The screenshots above show the screen where the error occurred. After the fix, clicking "Save & Continue" now correctly navigates to the next step.
