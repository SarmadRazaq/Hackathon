# Pipeline Optimization & Live Rescue Tracking

## Phase 1: Agent Consolidation (`orchestrator.py`)
- [x] Merge `vision_analyzer` and `signal_ingestor` into `multimodal_ingestor`.
- [x] Merge `response_planner` and `plan_verifier` into `safe_response_planner`.
- [x] Update DAG to run exactly 5 agents.
- [x] Update output keys and metadata in `run_pipeline` and `stream_pipeline`.

## Phase 2: Rescue Tracking Generation (`orchestrator.py`)
- [x] Update `execution_simulator` prompt to calculate and output `__RESCUE_DISPATCH__` JSON with start coordinates and ETA.

## Phase 3: Live Map UI (`ResultScreen.tsx`)
- [x] Parse `__RESCUE_DISPATCH__` from `simulation_results`.
- [x] Render ETA Banner in the overview.
- [x] Add `Polyline` to Map from start coordinate to epicenter.
- [x] Use `Animated.Region` or coordinate interpolation to animate a 🚑 marker.

## Phase 4: Verification
- [x] Restart backend.
- [x] Verify pipeline completes faster (~15-20s).
- [x] Verify map displays moving ambulance.
