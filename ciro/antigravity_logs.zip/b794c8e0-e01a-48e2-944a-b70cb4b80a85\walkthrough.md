# Walkthrough: Settings & Support Screens Refactor

## Changes
I've refactored the Settings and Support functionality from simple modals into dedicated, full-screen experiences.

### 1. New Screens
- **Settings Screen** (`src/screens/settings/SettingsScreen.tsx`):
    - Dedicated screen for account management.
    - **Sections**: Account, Security, Preferences, Danger Zone.
    - **Features**: Edit Profile, Change Password, Linked Accounts, Delete Account.
    - **UI**: Vertical list layout with chevron indicators, consistent with modern app design.

- **Support Screen** (`src/screens/settings/SupportScreen.tsx`):
    - **Sections**: Contact Us, About, Data.
    - **Features**: Help Center (Email), Send Feedback (Email), Rate Us (Store Link), Privacy Policy (Web), Export Data.

### 2. Navigation
- Updated `RootNavigator` to include `Settings` and `Support` routes.
- Updated `ProfileScreen` to navigate to these screens instead of opening local modals.

## Verification
1.  **Open Profile**: Tap the profile icon in the tab bar.
2.  **Navigate to Settings**: Tap "Settings".
    - Verify the list layout.
    - Tap "Edit Profile" and "Change Password" to see the internal modals.
    - Tap "Delete Account" to see the confirmation alert.
3.  **Navigate to Support**: Tap "Support & Info".
    - Tap "Rate Us" to check the link opening.
    - Tap "Export Data" to trigger the API call.

## Screenshots
*(If you run the app, you will see the new screens)*
