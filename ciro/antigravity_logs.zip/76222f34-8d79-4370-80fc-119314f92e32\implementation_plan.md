# Date Night Mobile Integration Fixes

The goal is to fix mobile responsiveness, camera/mic permissions, and matchmaking lobby logic for the Next.js `game-project` so it successfully embeds inside a Flutter `WebView`.

## User Review Required
No major architectural decisions require user review; these are configuration alignments and timeout extensions.

## Proposed Changes

---

### [Video & Audio Permissions]

The Next.js app asks Flutter for camera/microphone permissions but times out too quickly (1s for video, 0.8s for audio). This fails if the native dialog takes longer to process or the user reads it slowly.

#### [MODIFY] [videoService.ts](file:///f:/Git/game-project/client/lib/services/videoService.ts)
- Already successfully updated to 2500ms delay.

#### [MODIFY] [AudioRecorder.tsx](file:///f:/Git/game-project/client/components/DateNight/AudioRecorder.tsx)
- Increase the `setTimeout` on native microphone permission request from `800ms` to `2500ms`.
- Add the same friendly fallback text to the `permissionDenied` alert to instruct the user to check their device Settings if they missed the prompt.

---

### [Matches Inbox Token Invalidation]

The developer reported an "Invalid Token" error on the Matches Inbox screen. The component loads the JWT from `AuthStorage` correctly, but if it is expired or invalid on the API side, it simply displays the raw error string and fails to render the inbox, rather than logging the user out or attempting a refresh.

#### [MODIFY] [page.tsx](file:///f:/Git/game-project/client/app/matches/page.tsx)
- Catch `Failed to load matches` / `Invalid token` errors in `loadMatches`.
- Add a friendly empty state or a prompt to "Please log in again" rather than hanging the entire application on the error string.

---

### [Gift Selection Mobile Layout Gap]

The developer reported a large gap at the bottom of the "Choose Your Gift" screen. The parent Phaser component forces `100dvh` but sets `overflow: hidden`, causing WebViews with navigation bars to incorrectly trim the bottom of the canvas. The `GiftSelectionScene` itself uses absolute scaling and padding based on `height`.

#### [MODIFY] [PhaserGame.tsx](file:///f:/Git/game-project/client/components/DateNight/PhaserGame.tsx)
- Change the container `height` from `100dvh` to `100vh` to prevent mobile browser address bar layout jumps from breaking the canvas sizing.
- Ensure `position: absolute` and `inset: 0` are applied to the wrapper to fill the exact WebView footprint perfectly, eliminating the bottom gap offset.

---

### [DateNight Screen Responsiveness]

The Phaser scaling engine `Phaser.Scale.RESIZE` attempts to stretch natively, ignoring the logical UI layout of the scene.

#### [MODIFY] [dateNightGame.ts](file:///f:/Git/game-project/client/game/dateNightGame.ts)
- Already successfully updated to `Phaser.Scale.FIT` using `720x1280` base logical resolution.

## Verification Plan

### Automated Tests
- Run `npm run lint` and `npm run build` to ensure Next.js TypeScript compilation passes without errors.

### Manual Verification
- Ask the mobile developer to tap "Matches" with an invalid token and verify the app correctly prompts to log in instead of throwing a generic text error.
- Check the layout of `GiftSelectionScene` to ensure the canvas fills the entire screen.
- Verify `AudioRecorder` asks for permission and doesn't timeout natively on iOS/Android.al Resolution**: Hardcode `width: 720` and `height: 1280` as the internal base resolution, which fixes the UI element displacement across different device aspect ratios.
- **Enable `autoCenter`**: Set `autoCenter: Phaser.Scale.CENTER_BOTH` to perfectly center the game canvas in the WebView.

#### [MODIFY] `client/lib/services/videoService.ts`
- Update the `requestPermissions` method to give the Flutter native environment more time to process the permission request before throwing an error. Increase the delay from `1000ms` to `2500ms`, which will reduce race conditions when initializing ZegoCloud.
#### [MODIFY] `client/components/DateNight/VideoContainer.tsx`
- Ensure that the error UI clearly informs the user (and developer) about permission requirements and offers a retry mechanism if the WebView initially blocks the camera request.

## 4. Verification Plan

### Automated Tests
- Run `npm run build` on the Next.js client to verify that TypeScript compilation passes with the new Phaser scale configurations.

### Manual Verification
1. Run the local Next.js client.
2. Emulate a mobile device in the browser (e.g., iPhone 12/13) and verify that the Phaser UI (e.g., Lobby, Waiting Room) fits neatly inside the viewport without cutting off buttons.
3. Deny camera permissions explicitly in Chrome, and ensure the fallback Warning UI appears correctly with the "Retry" button.
