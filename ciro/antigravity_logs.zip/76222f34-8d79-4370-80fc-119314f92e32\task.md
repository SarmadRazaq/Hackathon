# Mobile Integration Fixes

- [ ] Analyze Phaser Game mobile responsiveness issues.
- [ ] Fix Phaser scaling mode in `dateNightGame.ts`.
- [ ] Analyze camera/microphone WebRTC permission race condition in `videoService.ts`.
- [ ] Fix permission waiting logic (increase timeout/poll for Flutter).
- [ ] Investigate "Waiting for date" hanging.
- [ ] Provide testing instructions for the mobile dev (2 players needed).
