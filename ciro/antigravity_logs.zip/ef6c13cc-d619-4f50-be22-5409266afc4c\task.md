# Audit Task List

- [x] Explore project structure <!-- id: 0 -->
- [x] Analyze Server Code <!-- id: 1 -->
- [x] Analyze Client Code <!-- id: 5 -->
- [x] Refactor `socket.controller.ts` <!-- id: 10 -->
- [x] Restore OTP Flow (Shelved) <!-- id: 14 -->
- [x] Harden Application (Error Handling & Edge Cases) <!-- id: 18 -->
- [x] Update Rose Mechanics & Lore <!-- id: 23 -->
- [x] Audit Date Night Requirements <!-- id: 27 -->
- [ ] Audit Date Night Edge Cases <!-- id: 33 -->
    - [x] Disconnections during Gift Phase <!-- id: 34 -->
    - [x] Both players waiting for Gift indefinitely <!-- id: 35 -->
    - [x] Location Approval timeouts or rejections <!-- id: 36 -->
    - [x] Question Flow race conditions (both asking) <!-- id: 37 -->
    - [x] Early Exit during Match Flow <!-- id: 38 -->
