# Milestone 1 Phase 1 — Walkthrough

## Summary
All Milestone 1 / Phase 1 deliverables have been implemented. The core game engine foundation is complete with full rule enforcement, Inspector-configurable values, and a playable solo session.

---

## Changes Made

### 1. New File: `GameConfig.cs`
Central `ScriptableObject` that satisfies the deliverable: *"PBA win threshold, DTA win target, and rent multipliers must be editable in the Unity Inspector without changing the code."*

| Parameter | Default | Purpose |
|-----------|---------|---------|
| `startingPBA` | 5,000 | Initial Player Bank Amount |
| `startingDTA` | 0 | Initial Total Asset Value |
| `passStartSalary` | 200 | PBA awarded when passing Start |
| `pbaWinThreshold` | 10,000 | PBA ≤ this to win |
| `dtaWinTarget` | 300,000,000 | DTA ≥ this to win |
| `requiredPropertyCountToWin` | 0 | Must own exactly this many properties to win |
| `maxImprovementLevel` | 5 | 4 add-ons + 1 specialty |
| `wholesaleMultiplier` | 1.5 | Selling wholesale multiplier |
| `defaultRentMultipliers` | {1, 2.2, 4.5, 8.5, 15, 24} | Rent multiplier by improvement level |

> **To use**: In Unity, right-click in Project → Create → Big Spender → Game Config. Then assign it to any manager's `gameConfig` field.

---

### 2. Bug Fix: Consolidated Sell-to-Bank

**Before**: `GameManager.SellPropertyToBank()` contained its own duplicate implementation (reset tile state, add to DTA, remove from owned list). `PropertyManager.SellToBank()` had the same logic independently.

**After**: `GameManager.SellPropertyToBank()` now delegates to `PropertyManager.SellToBank()`. Single source of truth.

render_diffs(file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/GameManager.cs)

---

### 3. Dead Code Removal

Removed `ApplyTileInteraction()` and `HandlePropertyTileInteraction()` — two methods that were never called. All landing logic flows through `OnPlayerLand()` → `HandleNonPropertyTileInteraction()`.

---

### 4. Compile Fix: `ProductionVisualTheme.cs`

Fixed 3 calls to `FindObjectsByType<T>()` that were missing the required `FindObjectsSortMode` parameter in Unity 6:
- `FindObjectsByType<Tile>()` → `FindObjectsByType<Tile>(FindObjectsSortMode.None)`
- `FindObjectsByType<PlayerProfile>()` → `FindObjectsByType<PlayerProfile>(FindObjectsSortMode.None)`
- `FindObjectsByType<Light>()` → `FindObjectsByType<Light>(FindObjectsSortMode.None)`

---

### 5. Solo Player Auto-Spawn

If no players are found in the scene (no "Player"-tagged objects and none assigned manually), `GameManager.Start()` now auto-spawns a single capsule at Tile_0 with:
- `PlayerProfile` component (tokenColorId = "Red")
- `PlayerMovement` component
- `GameConfig` wired in (if available)

This enables the **"playable solo session"** deliverable out-of-the-box.

---

### 6. GameConfig Wiring

All managers now accept an optional `GameConfig` reference and prefer it over their local Inspector fields:

| Script | Fields Read from GameConfig |
|--------|---------------------------|
| `PlayerProfile` | `startingPBA`, `startingDTA` |
| `WinManager` | `pbaWinThreshold`, `dtaWinTarget`, `requiredPropertyCountToWin` |
| `EconomyManager` | `passStartSalary` |
| `PropertyManager` | `maxImprovementLevel`, `wholesaleMultiplier` |
| `GameManager` | `maxImprovementLevel`, `wholesaleMultiplier` |
| `Tile` | New `GetWholesaleValue(float)` overload accepts external multiplier |

All fallback to their existing hardcoded defaults when no `GameConfig` is assigned — **zero breaking changes**.

---

## Files Modified

| File | Change |
|------|--------|
| [GameConfig.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/GameConfig.cs) | **NEW** — Central config SO |
| [GameManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/GameManager.cs) | GameConfig wire, sell consolidation, dead code removal, auto-spawn |
| [PropertyManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/PropertyManager.cs) | GameConfig wire for maxLevel/wholesale |
| [WinManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/WinManager.cs) | GameConfig wire for win thresholds |
| [EconomyManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/EconomyManager.cs) | GameConfig wire for pass-start salary |
| [PlayerProfile.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/PlayerProfile.cs) | GameConfig wire for starting PBA/DTA |
| [Tile.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/Tile.cs) | New `GetWholesaleValue(float)` overload |
| [ProductionVisualTheme.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/ProductionVisualTheme.cs) | Compile fix (FindObjectsSortMode) |

---

## How to Verify in Unity

1. Open the scene and press **Play**
2. Confirm a solo player capsule auto-spawns at Tile_0
3. The color-coded dice roll determines starting order (even with 1 player)
4. Click **ROLL DICE** → player hops step-by-step
5. Pass GO → PBA increases by 200 (configurable)
6. Land on unowned property → Buy UI appears
7. Land on owned property → Upgrade or Sell UI appears
8. Only 1 upgrade per turn accepted
9. Sell to bank → wholesale value goes to DTA (not PBA)
10. To test win: In Inspector, set starting DTA to 300M, starting PBA to 5000, properties to 0, and confirm victory triggers

### To Create GameConfig Asset
Right-click in Project panel → **Create → Big Spender → Game Config** → Assign to managers' `gameConfig` slots
