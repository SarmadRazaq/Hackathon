# Migrate Admin Command Center to Next.js

The objective is to migrate the current vanilla HTML/JS Admin Panel (`backend/static/index.html`) into a modern, component-driven Next.js architecture while preserving its premium aesthetic and highly dynamic functionality (Leaflet animations, SSE streams, Playbook Polling, and PDF generation). 

## User Review Required

> [!WARNING]
> Moving to Next.js introduces a separate frontend dev server (`localhost:3000`). For local development, you will need to run the Next.js development server alongside the FastAPI backend. Are you okay with having two separate processes running (one for Next.js, one for FastAPI)?

> [!IMPORTANT]
> The system guidelines require avoiding Tailwind CSS unless explicitly requested. I will initialize Next.js using **Vanilla CSS Modules / Global CSS** to maintain our custom design tokens and maximize layout flexibility unless you prefer Tailwind.

## Proposed Changes

We will create a new directory `admin_panel` at the root of the project to house the Next.js application.

---

### Initialize Next.js App
#### [NEW] `admin_panel/`
- Initialize standard Next.js (App Router, TypeScript, ESLint, No Tailwind).
- Ensure `NEXT_PUBLIC_API_URL` is set to `http://localhost:8000` to correctly route requests to the FastAPI backend.

---

### Core Components
We will modularize the monolithic HTML file into maintainable React components:

#### [NEW] `admin_panel/src/app/globals.css`
- Migrate all custom CSS variables, themes, scrollbar styles, and glassmorphic layouts from `index.html`.

#### [NEW] `admin_panel/src/app/page.tsx`
- The main orchestration page. Manages global state such as the `activeScenario`, `pipelineStatus`, `agentLogs`, and `simulationResults`.
- Handles the Server-Sent Events (`EventSource`) logic to stream the multi-agent pipeline from the backend in real-time.

#### [NEW] `admin_panel/src/components/Sidebar.tsx`
- Fetches and displays available scenarios from `/api/scenarios`.

#### [NEW] `admin_panel/src/components/LiveAgentStream.tsx`
- Renders the beautifully formatted, Slack-style agent chat UI.
- Auto-scrolls to the bottom when new logs stream in.

#### [NEW] `admin_panel/src/components/SimulationResults.tsx`
- Displays the impact metrics (Congestion Drop, Time Saved) and tactical mitigations.
- Contains the "Official PDF Briefing" logic to launch the native browser print window.

#### [NEW] `admin_panel/src/components/OperationsTracker.tsx`
- Implements the real-time `setInterval` polling to fetch the responder playbook checklist from `/api/playbook/{session_id}`.
- Renders the smooth teal progress bar.

#### [NEW] `admin_panel/src/components/CrisisMap.tsx`
- Wraps Leaflet.js logic using `useEffect`. 
- Due to Leaflet's dependency on `window`, this component will be dynamically imported in Next.js (`next/dynamic` with `ssr: false`).
- Re-implements the dynamic animated vehicle routing (`animateVehicleRoute`).

---

### Cleanup
#### [MODIFY] `backend/main.py`
- (Optional) Modify the root `/` endpoint or just leave it as an Easter Egg, but primarily we will now rely on `http://localhost:3000` for the Web Dashboard.

## Verification Plan

### Automated/Manual Verification
- Run the Next.js development server.
- Verify the Command Center successfully fetches scenarios.
- Run the "Flash Flood" scenario and verify the agent stream correctly visualizes in the new React state.
- Ensure the Leaflet Map accurately draws bounding boxes and animates the rescue ambulance without SSR errors.
- Trigger the Playbook Progress Tracker and generate a PDF to confirm feature parity.
