# Diet Plan Filtering by User Goal, BMI & Cuisine

Filter the diet plans shown in the app based on the user's onboarding selections (goal, BMI category, cuisine preference), instead of showing all plans.

## Open Questions

> [!IMPORTANT]
> **How are diet plans categorized in the backend?** The `DietPlan` interface has a `category` field (string) and a `name` field. I need to know:
> 1. Does the `category` field match goal names exactly (e.g., `"Lose weight"`, `"Gain Weight"`)? Or is it something like `"Weight Loss"`, `"Muscle Building"`?
> 2. Does the plan `name` contain the cuisine type (e.g., `"Traditional Weight Loss Overweight Plan"`)? Or is there a separate field for cuisine type?
> 3. Do diet plans have a BMI category field (e.g., `"overweight"`, `"obese"`)? Or do I need to infer this from the plan name/description?
>
> **I need to see the actual API response** to determine the exact field names. Since the server is currently returning 502, I'll build a flexible filtering system that matches against `category` and `name` fields.

## Proposed Changes

### Approach
Since the backend is down (502), I'll implement **client-side filtering** in the diet screen. The flow:

1. **Fetch user's questionnaire data** (goal, dietType, height, weight) from the questionnaire API endpoints
2. **Calculate BMI category** from height + weight
3. **Filter diet plans** by matching the user's goal against `plan.category`
4. **Sort plans** so the user's selected cuisine appears first
5. **Show remaining cuisines** for the same goal + BMI category after the selected one

---

### 1. Extend UserContext with Goal & Diet Type

#### [MODIFY] [UserContext.tsx](file:///f:/Git/lifeline/contexts/UserContext.tsx)
Add `goal` and `dietType` fields to `UserProfile` so they're available globally:
- Map from `latestQuestionnaire?.goal` and `latestQuestionnaire?.dietType`

---

### 2. Filter & Sort Diet Plans in the Diet Screen

#### [MODIFY] [diet.tsx](file:///f:/Git/lifeline/app/(tabs)/diet.tsx)
- Import `useUser` context to get `goal`, `dietType`, `weight`, `goalWeight`, `height`
- Calculate BMI category from weight + height
- Filter `dietPlans` to only show plans whose `category` matches the user's `goal`
- Secondary filter by BMI-related keywords in plan name/description (if present)
- Sort: move plans matching user's selected `dietType` (cuisine) to the front
- Fallback: if no matching plans found, show all plans with a message

---

### 3. Add BMI Utility

#### [NEW] [bmiUtils.ts](file:///f:/Git/lifeline/utils/bmiUtils.ts)
Small utility to calculate BMI and return the category:
```typescript
export function calculateBMI(weightKg: number, heightCm: number): number
export function getBMICategory(bmi: number): 'underweight' | 'normal' | 'overweight' | 'obese'
```

---

## Verification Plan

### Manual Verification
1. Log in with a user who selected "Lose weight" goal and "Traditional" cuisine
2. Verify only weight-loss diet plans appear
3. Verify the Traditional cuisine plan is listed first
4. Verify other cuisines (Keto, Mediterranean, etc.) follow
5. Check that a user with "Gain Weight" goal sees different plans
