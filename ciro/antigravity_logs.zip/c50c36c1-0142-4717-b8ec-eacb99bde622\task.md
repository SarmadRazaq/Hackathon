# BlackLivery App Tasks

## Completed
- [x] Fix UI toggle/chip sizing and contrast (service_toggle, my_rides, airport_booking)
- [x] Fix Google Sign-In button wiring
- [x] Fix Android build configuration
- [x] Seed test data for Firebase Auth + Firestore
- [x] Implement Biometric Login + Twilio 2FA (Rider + Driver)
- [x] Fix Support button not working (Wallet Screen)
- [x] Fix Payment Method "Cash Only" / Add Card error
- [x] Fix Invalid Email (Paystack 400)
- [x] Fix URL Launch (AndroidManifest.xml)
- [x] Full Platform Gap Analysis → `gap_analysis.md`
- [x] **Item 5**: Rating-based priority matching in `findNearbyDrivers()`
- [x] **Item 6**: Payment gateway selector (Paystack/Flutterwave) in rider app
- [x] **Item 8**: Zone-based pricing seed data (Lagos/Abuja/Chicago — 17 zones)
- [x] **Item 9**: B2B delivery pricing tiers + admin CRUD routes

## Deferred
- [ ] **Item 7**: FlutterFlow UI migration — user chose to keep existing apps + Figma styling

## Pending
- [ ] Verify Payment Page Opening (Paystack checkout)
- [ ] Production deployment planning
- [ ] Firebase production project setup
