# Wire Driver Preferences to App Behavior

- [x] Filter incoming ride/delivery requests in `RideProvider` based on preferences
- [x] Emit driver preferences to backend via socket on change
- [x] Auto-decline rides/deliveries/scheduled/long/short/airport based on toggles
- [x] Auto-greeting: send chat message on ride accept when enabled
- [x] Emit driver mode (ride/delivery/both) via socket on Go Online
- [x] Send quiet mode notification in auto-greeting

# Redesign Driver Onboarding Screens

- [x] Redesign `PhoneEntryScreen` (Step 1)
- [x] Redesign `OtpVerificationScreen` (Step 1, 6-digit support)
- [x] Redesign `CreateAccountScreen` (Step 2)
- [x] Redesign `EmergencyContactsScreen` (Step 3)
- [x] Redesign `VerificationScreen` (Step 4, documents/vehicle)
- [x] Create/Redesign `AccountSetupScreen` (Step 6, payout)
- [x] Redesign `SuccessScreen` (Step 7, auto-navigate)
- [x] Verify backend integration (AuthService method names)

# Personal Info Screen Redesign

- [x] Implement `updateProfile` in `AuthService` (Core)
- [x] Expose `updateProfile` in `AuthProvider`
- [x] Redesign `PersonalInfoScreen` (Dark theme, Cards)
- [x] Implement Phone Update Logic
- [x] Handle Email Update (ReadOnly/Toast) - UPDATED to Allow Edit
- [x] Fix Earnings Dashboard 404 (Missing /api/v1 prefix)
- [x] Fix PersonalInfoScreen Logout Navigation

# Emergency Contacts Redesign

- [x] Audit existing `EmergencyContactsScreen`
- [x] Implement `flutter_contacts` and permissions
- [x] Build "Empty State" UI (Info Card)
- [x] Build "Choose Contacts" UI (Search + List)
- [x] Build "Contacts List" UI (Added contacts + Delete)
- [x] Integrate with Backend `updateProfile` (emergencyContact field)

# Refine Onboarding Flow

- [x] Pass Name/Email from `PhoneEntryScreen` to `OtpVerificationScreen`
- [x] Pass Name/Email from `OtpVerificationScreen` to `CreateAccountScreen`
- [x] Pre-fill Name/Email in `CreateAccountScreen`
- [x] Fix "401 Unauthorized" in Emergency Contacts (Added Email Verification Step)

# Single OTP Screen Flow

- [x] Update `AuthService` to accept password for verification
- [x] Update `AuthProvider` to pass password
- [x] Update `Splash Screen` to start at `CreateAccountScreen`
- [x] Update `CreateAccountScreen` to navigate to `OtpVerificationScreen`
- [x] Update `OtpVerificationScreen` to complete registration
- [x] Fix "Bottom Overflowed" in "Select Your Car" modal (Added scrolling)
- [x] Add Testing Mode to bypass document validation in `VerificationScreen`
- [x] Allow Unapproved Drivers to Go Online (Backend Bypass)

# Earnings Screen Redesign

- [x] Add `fl_chart` dependency
- [x] Create `EarningsService` and `EarningsProvider` (Backend & Frontend)
- [x] Implement `EarningsScreen` UI Layout (Widgets created)
- [x] Build `TodayEarningsCard` (Arc)
- [x] Build `WeeklyInteractiveChart`
- [x] Build `MonthlyInteractiveChart`
- [x] Connect components in `EarningsScreen.dart`
- [x] Integrate Real Data from Backend (Via EarningsService)
- [x] Fix ApiClient and Provider Errors (Restored missing methods)

# Settings Screen Redesign

- [x] Redesign `SettingsScreen` Layout (Groups, Icons, Colors)
- [x] Remove Profile Header & Section Titles
- [x] Implement "Log Out" as list item in Group 2
- [x] Add Version Number at bottom
