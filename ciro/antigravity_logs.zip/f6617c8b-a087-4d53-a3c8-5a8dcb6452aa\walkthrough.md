# Remediation Walkthrough

This document outlines the changes made to prepare the BlackLivery backend and admin panel for production on EC2.

## 1. Backend CORS Safety
We added a safety check in `backend/src/server.ts` that warns you if `CORS_ORIGINS` is missing in production.

### Verification
To verify this locally:
1.  Navigate to `backend` directory.
2.  Run `npm run start` (simulating production start).
3.  Observe the logs. You should see a warning if `CORS_ORIGINS` is not set in your `.env`.

**Production Action Item**:
When configuring your EC2 instance, ensure you set the environment variable:
```bash
export CORS_ORIGINS="https://admin.yourdomain.com,https://app.yourdomain.com"
```
(Or add it to your production `.env` file).

## 2. Admin Panel Build Safety
We modified `frontend-adminpanel/vite.config.ts` to check for `VITE_API_URL` during the build process.

### Verification
1.  Navigate to `frontend-adminpanel`.
2.  Run `npm run build`.
3.  Check the console output. It will print a warning if `VITE_API_URL` is not detected.

**Production Action Item**:
In your CI/CD pipeline or build script, ensure you pass the API URL:
```bash
VITE_API_URL=https://api.yourdomain.com npm run build
```

## Summary of Changes
- **Backend**: Added startup warning for unsafe CORS config.
- **Backend Docs**: Updated `.env.example` with `CORS_ORIGINS`.
- **Admin Panel**: Added build-time warning for missing API URL.
