# Goal

Restart the evaluation process safely and generate immediate, real results for your paper without deleting your past logs or failed runs.

## Context & Bug Fixes
The previous SWE-bench runs failed instantly for all 300 instances due to two Windows-specific bugs that I have now squashed:
1. **Encoding Errors**: The Python `subprocess` and `print` statements were defaulting to Windows `cp1252` encoding, crashing on Unicode characters (like `→`) in the SWE-bench logs. I've enforced `utf-8` across the entire framework.
2. **Corrupted Git Patches**: Windows line-ending conversions (`\r\n`) were corrupting the `git apply` process for SWE-bench test patches. I've updated the script to write patches in binary mode and clone repos with `core.autocrlf=false` to ensure clean application.

## Open Questions
> [!IMPORTANT]
> **Which evaluation results do you need first for your paper?**
> 1. **Baseline Comparisons (eval.py)**: Compares DRV against ReAct, ADaPT, and SelfRefine across 15 tasks. 
> 2. **SWE-bench Evaluation**: Tests DRV's ability to resolve real GitHub issues.

## Proposed Changes

Since a full SWE-bench run (300 instances) or full baseline evaluation takes hours, I propose generating a **"Preliminary Results Dataset"** that you can use *immediately* to start writing your paper, while the full runs continue in the background.

### Step 1: Preliminary Baseline Evaluation
Run `eval.py` on a subset of 3 representative tasks (one short, one medium, one long horizon) using the actual LLM. 
- **Output**: This will generate a fresh `results_prelim.csv` and a `horizon_degradation_prelim.png` chart comparing DRV with the baselines.
- **Time**: ~5-10 minutes.

### Step 2: Preliminary SWE-bench Evaluation
Run `run_swebench.py` on 3 fresh instances into a new output file (`swebench_prelim.csv`), preserving your old `swebench_results.csv`.
- **Output**: End-to-end SWE-bench resolution logs and metrics for the first few instances.
- **Time**: ~10-15 minutes.

### Step 3: Background Full Runs
Once you have the preliminary data for your paper, I can launch the full 15-task `eval.py` and 300-instance `run_swebench.py` in the background for you to collect overnight.

## Verification Plan

### Automated Tests
- I will run `python run_swebench.py --repos-root ./repos_prelim --max-instances 1 --results-csv prelim_swebench.csv --results-jsonl prelim_swebench.jsonl` to prove the `git apply` corrupt patch bug is permanently fixed.
- I will verify that `horizon_degradation_prelim.png` is generated successfully.
