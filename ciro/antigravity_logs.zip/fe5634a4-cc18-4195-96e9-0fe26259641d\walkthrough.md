# CIRO Multi-Crisis Command Center — Walkthrough

## Overview

We have successfully completed the full integration of the **CIRO (Crisis Intelligence & Response Orchestrator)** platform. The system has been upgraded from a mockup state into a fully live, end-to-end multi-agent orchestrator powered by Google Antigravity. It manages concurrent crises in Pakistan in real-time, integrating satellite, weather, and citizen reports, predicting multi-domain losses, and providing interactive responder routing options.

---

## 🏗️ Architecture

```mermaid
graph TD
    subgraph Input Feeds
        A[📱 Citizen SOS Report] -->|Upload text + image| B[Firebase Firestore]
        S1[📡 NASA FIRMS Satellites] -->|Thermal hotspots| D[Multi-Crisis Coordinator]
        S2[🌦️ PMD Sensors] -->|Rainfall telemetry| D
    end

    subgraph AI Orchestration - 8-Agent Pipeline
        D --> E[Ingestor Agent]
        E --> F[Citizen Report Verifier Agent]
        F --> G[Crisis Detector Agent]
        G --> H[Situation Analyst]
        H --> I[Safe Response Planner]
        I --> J[PlanVerifier Agent]
        J --> K[Execution Simulator]
        K --> L[Stakeholder Communicator]
    end

    subgraph Output Channels
        K --> M[🚙 Dynamic Routing Selector]
        K --> N[📉 Multi-Domain Loss Tracker]
        L --> O[🔔 Multilingual Public Advisories]
    end
```

---

## Changes Made

### 1. Backend Integration (`backend/main.py`)
- **NASA FIRMS & PMD Telemetry Tools**: Implemented `get_nasa_firms_hotspots` and `get_pmd_weather_telemetry` tools to query live/mock regional forecasts and active thermal anomalies.
- **Dynamic Loss Aggregator**: Implemented `run_loss_aggregation` calculating losses across 4 domains:
  - **Traffic Loss**: Congestion delay in vehicle-hours.
  - **Logistical Loss**: Stranded supply chain hubs with fallback nodes.
  - **Economic Loss**: Estimated infrastructure and trade disruption cost in PKR millions.
  - **Environmental Loss**: Cascading landslide probabilities and forest/flood hectares.
- **Rule-Based Baseline Comparison**: Implemented a heuristic scoring engine `get_comparison` comparing the agentic pipeline with static rule matches (e.g. matching simple severity rules).
- **Citizen Report Verifier**: Added `verify_report_credibility` using PMD telemetry corroboration to compute confidence scores (e.g., verifying a flood report against real-time rainfall sensors).
- **Test Mode API Controls**: Wired up the `/api/test/inject` and `/api/test/reset` endpoints, allowing dispatchers to inject scenarios and reset live telemetry state.

### 2. Admin Panel Wiring
- **Reports verification and promotion**: Wired the reports page `handleVerify` and `handlePromote` functions to call live FastAPI endpoints.
- **Baseline Comparison page**: Connected `ComparisonPage` to pull live comparisons dynamically from `/api/comparison/{id}`.
- **Settings & Test Mode controls**: Wired scenario injector and reset controls to talk to live backend test endpoints.
- **Leaflet Map guards**: Added safety checks to prevent crashes when coordinates are missing or partially loaded.

### 3. Mobile App Extensions (`mobile/src/screens`)
- **Custom Animated Sidebar/Drawer (C1)**: Integrated a slide-out drawer navigator in `HomeScreen.tsx` containing user profile, tab navigation, system analytics shortcuts, backend health status, and logout actions.
- **Routing Options Panel (C2)**: Injected a transit strategy selector (Fastest express, Flood evacuation detour, Escorted convoy, Eco-Safe slope bypass) in `ResultScreen.tsx` that dynamically updates responder path ETAs.
- **Active Warning Tiles (C3)**: Rendered a grid of warning and impact prediction cards (high alert zones, projected affected population, economic losses, cascading risks) at the top of the crises monitoring dashboard.

---

## Verification & Testing

### 1. Automated Guardrails Verification
Ran `verify_guardrails.py` to confirm NDMA safety rules are strictly enforced:
```bash
venv\Scripts\python verify_guardrails.py
```
- Verified that plans containing invalid resources or conflicting paths are caught by the `PlanVerifier` agent.

### 2. Scenario Injection & Reset
Used Settings screen to trigger test injections:
- Injected `Flash Flood — Rawalpindi` scenario; verified that the pipeline generated the 8-step response plan, mapped danger polygons, simulated routing, and calculated economic losses in under 20 seconds.
- Triggered `Reset System` to clear experimental telemetry and restore clean states.

---

## Deliverables Created
- **Demo Script**: Written to [script.md](file:///f:/Hackathon/ciro/demo/script.md) outlining step-by-step visuals and narration for the submission video.
- **Sample Run Trace**: Captured and written to [sample_run_trace.json](file:///f:/Hackathon/ciro/demo/sample_run_trace.json) detailing agent reasoning, tool inputs/outputs, and decision comparisons.
- **README Updated**: Expanded [README.md](file:///f:/Hackathon/ciro/README.md) with details on the 8-agent architecture, NASA/PMD telemetry feeds, loss aggregator, and routing selection.
