# Implementation Plan — Items 5–9

## Overview

Five enhancements to bring BlackLivery to production readiness. Items 5, 6, 8, 9 are code changes. Item 7 requires a decision from the user.

---

## Item 5: Rating-Based Priority Matching

**Goal**: Higher-rated drivers get offered rides first.

### [MODIFY] [RideService.ts](file:///F:/BlackLivery/backend/src/services/RideService.ts)

In `findNearbyDrivers()` (line ~325), change the final sort from distance-only to a weighted sort:

```diff
-.sort((a, b) => a.distanceKm - b.distanceKm);
+.sort((a, b) => {
+    // Rating tiers: 4.8+ = priority, 4.5-4.7 = neutral, <4.5 = deprioritized
+    const ratingA = a.profile.rating ?? 4.5;
+    const ratingB = b.profile.rating ?? 4.5;
+    const tierA = ratingA >= 4.8 ? 0 : ratingA >= 4.5 ? 1 : 2;
+    const tierB = ratingB >= 4.8 ? 0 : ratingB >= 4.5 ? 1 : 2;
+    if (tierA !== tierB) return tierA - tierB; // Higher-rated tier first
+    return a.distanceKm - b.distanceKm;        // Same tier → closer first
+});
```

**Effort**: ~5 minutes. Single sort change.

---

## Item 6: Payment Gateway Selector in Rider App

**Goal**: Let riders choose Paystack or Flutterwave when adding a payment method.

### [MODIFY] [add_payment_method_screen.dart](file:///F:/BlackLivery/mobile/rider/blacklivery/blackliveryrider/lib/presentation/pages/add_payment_method_screen.dart)

1. Add a `_selectedGateway` state variable (default: `'paystack'`)
2. Add a dropdown/segmented control with options: Paystack, Flutterwave
3. Pass `gateway` param in the `initiatePayment` request body

### [MODIFY] [payment_service.dart](file:///F:/BlackLivery/mobile/rider/blacklivery/blackliveryrider/lib/core/services/payment_service.dart)

Add optional `gateway` parameter to `initiatePayment()`:

```diff
 Future<Map<String, dynamic>?> initiatePayment({
   required double amount,
   required String rideId,
   String? currency,
   String? purpose,
+  String? gateway,
 })
```

**Effort**: ~15 minutes. UI + service param.

---

## Item 7: FlutterFlow UI Migration

> [!IMPORTANT]
> This is a **large decision** that affects project direction. Two options:

| Option | Effort | Risk |
|--------|--------|------|
| A. Keep current Flutter apps, apply Figma styling updates | Medium | Low — existing logic preserved |
| B. Export FlutterFlow project and replace apps | Very Large | High — need to re-wire all services, APIs, WebSockets |

**Recommendation**: Option A — keep current apps and update styling from Figma. The existing apps have 55+ (rider) and 28 (driver) screens with full backend integration. Replacing them with FlutterFlow output would require re-implementing all service layers.

> [!WARNING]
> **User decision required** — which option do you prefer?

---

## Item 8: Zone-Based Pricing Seed Data

**Goal**: Seed Firestore with zone-specific pricing overrides for Lagos, Abuja, and Chicago.

### [NEW] [seed-pricing-zones.ts](file:///F:/BlackLivery/backend/src/scripts/seed-pricing-zones.ts)

Create a script that writes zone documents to `config/pricing_zones` collection:

**Nigeria Zones:**
- VI (Victoria Island), Lekki, Ajah, Ikeja GRA, Wuse II, Garki, Maitama, Bannex, Port Harcourt GRA

**Chicago Zones:**
- Loop, Gold Coast, Hyde Park, North Side, Evanston, Schaumburg, Naperville

Each zone document:
```json
{
  "name": "Victoria Island",
  "region": "NG",
  "city": "lagos",
  "bounds": { "lat": 6.4281, "lng": 3.4219, "radiusKm": 3 },
  "surgeMultiplier": 1.2,
  "priceAdjustment": 1.0
}
```

### [MODIFY] [SurgeService.ts](file:///F:/BlackLivery/backend/src/services/pricing/SurgeService.ts)

Add zone lookup in `calculateDynamicSurge()` to check if location falls within a defined zone and apply its multiplier.

**Effort**: ~20 minutes. Script + minor service update.

---

## Item 9: B2B Delivery Pricing Tiers

**Goal**: Bulk business accounts get tiered discounts per the spec.

### [NEW] [B2BPricingService.ts](file:///F:/BlackLivery/backend/src/services/pricing/B2BPricingService.ts)

New service with:
- `getBusinessTier(businessId)` — lookup monthly delivery count → tier
- `applyBusinessDiscount(baseFare, tier)` — apply tier discount

Tiers:
| Monthly Deliveries | Discount | Commission |
|--------------------|----------|------------|
| 0–200 | 0% | 25% |
| 200–500 | 10% | 20% |
| 500–2000 | 15% | 18% |
| 2000+ | Custom | 15–18% |

### [MODIFY] [delivery.controller.ts](file:///F:/BlackLivery/backend/src/controllers/delivery.controller.ts)

In `createDelivery()` and `getDeliveryQuote()`, check if the user has a business account and apply the tier discount.

### [NEW] Admin API endpoints

- `GET /api/v1/admin/b2b-accounts` — list business accounts
- `POST /api/v1/admin/b2b-accounts` — create business account
- `PUT /api/v1/admin/b2b-accounts/:id` — update tier/discount

**Effort**: ~30 minutes. New service + controller updates + admin routes.

---

## Verification Plan

### Automated Tests
- `npm run dev` — verify backend compiles with items 5, 8, 9
- `flutter run` — verify rider app builds with items 6

### Manual Verification
- Item 5: Check server logs for driver offer order (higher-rated first)
- Item 6: Tap "Add Card" → see gateway selector → choose Flutterwave → verify redirect URL
- Item 8: Run seed script → verify Firestore `config/pricing_zones` documents
- Item 9: Create test B2B account → request delivery quote → verify discount applied
