# Implementation Plan: Audit and Fixes for BlackLivery Apps

## Goal Description
Audit the Rider, Driver, and Admin applications for mock data, verify backend integration, check push notification implementation, and address edge cases. The ultimate goal is to remove all mock data from the frontend, ensuring proper integration with the backend, and that the applications are robust against common edge cases.

## Proposed Changes

### Driver App (Flutter)
- Remove mock data implementations in:
  - `Earnings Dashboard` and `Earnings Gauge` (currently uses `MockEarningsData` and hardcoded targets).
  - `Bookings Screen` and `Ride History Screen` (currently uses mockups for items).
  - `Vehicle Info Screen` (uses mock images to satisfy backend validation).
  - `Approval Screen` (uses mock approval check).
  - `Ride Modes Screen` (uses mock dots indicator).
- Implement real API calls for the above features and handle loading/error/empty states (edge cases).

### Rider App (Flutter)
- Ensure all `Future.delayed` calls used for UI pacing are not hiding missing backend implementations. (Mostly UI delays found, but will double-check OTP and Delivery bookings).
- Review edge case handling (network errors, empty lists).

### Admin Panel (React/Web)
- Search for and remove any `dummy` data or bypassed API calls.

### Push Notifications
- Push notifications are fully implemented structurally using Firebase Cloud Messaging (FCM) across Rider, Driver, and Backend.
- Verify that permissions and token refreshes are handled gracefully as edge cases.

### Final E2E Critical Review & Edge Cases (Pre-Delivery Fixes)
> [!CAUTION]
> **CRITICAL VULNERABILITY: Payment Ghosting (Paystack fallback)**
> In `backend/src/services/payment/providers/PaystackProvider.ts`, if `PAYSTACK_SECRET_KEY` is missing from the `.env` file, the system silently uses a mock token (`sk_test_mock_key_for_dev`). This allows real-world rides to "succeed" in production without capturing actual funds. We MUST throw a strict configuration error instead of falling back to mock payments in production.

> [!WARNING]
> **SEVERE EDGE CASE: "Zombie" Drivers (Matchmaking Failure)**
> In `backend/src/services/DriverStatusService.ts`, the cron job that culls disconnected drivers sets `DRIVER_AUTO_OFFLINE_MS` to **12 hours**. This means a driver whose internet disconnected will still receive ride requests for 12 hours. We need to reduce this threshold to `5 minutes` maximum (300,000 ms).

- **Rider App UI Bug**: Reviewing `modify_ride_screen.dart` revealed a TODO indicating that car details are not mapped properly to the offline/past `RideHistoryItem` model. We should ensure past rides display the correct vehicle type used.

## Verification Plan
### Automated Tests
- Run existing Flutter unit tests to ensure API clients and providers still work after removing mock dependencies.
### Manual Verification
- Launch Driver app and verify Earnings/History data correctly fetches from the backend instead of displaying mock data.
- Test network disconnection to see if API client intercepts and shows appropriate UI feedback.
- Change `.env` file and observe backend crashing intentionally if payment gateways are misconfigured.
