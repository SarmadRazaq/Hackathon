# Frontend–Backend Alignment Audit

## Architecture Overview

```mermaid
graph TD
    subgraph Backend ["Backend (Express.js)"]
        APP["app.ts — /api/v1/*"]
        AUTH["/auth — 15 endpoints"]
        RIDE["/rides — 9 endpoints"]
        DELIVER["/deliveries — 5 endpoints"]
        PAY["/payments — 13 endpoints"]
        VEH["/vehicles — 5 endpoints"]
        PAYOUT["/payouts — 7 endpoints"]
        ADMIN["/admin — 40+ endpoints"]
        DRIVER["/driver — 11 endpoints"]
        PROMO["/promotions — 3 endpoints"]
        SUPPORT["/support — 6 endpoints"]
        CHAT["/chat — 4 endpoints"]
        PLACES["/places — 7 endpoints"]
        LOYALTY["/loyalty — 5 endpoints"]
        CONTACTS["/contacts — 4 endpoints"]
    end

    RIDER["Rider App (Flutter)"] --> AUTH & RIDE & DELIVER & PAY & PROMO & SUPPORT & CHAT & PLACES & CONTACTS
    DRVR["Driver App (Flutter)"] --> AUTH & RIDE & DRIVER & VEH & PAYOUT & CHAT & SUPPORT
    ADMINP["Admin Panel (React)"] --> AUTH & ADMIN & SUPPORT
```

---

## Alignment Summary

| Area | Rider App | Driver App | Admin Panel |
|------|-----------|------------|-------------|
| **Auth** | ✅ Aligned | ✅ Aligned | ✅ Aligned |
| **Rides** | ✅ Aligned | ✅ Aligned | ✅ Aligned |
| **Payments** | ✅ Aligned | N/A (driver-side) | N/A |
| **Deliveries** | ✅ Aligned | N/A | ⚠️ Uses rides endpoint |
| **Chat** | ✅ Aligned | ✅ Aligned | N/A |
| **Places** | ✅ Aligned | N/A | N/A |
| **Contacts** | ✅ Aligned | N/A | N/A |
| **Promotions** | ✅ Aligned | N/A | ✅ Aligned |
| **Support** | ✅ Aligned | ✅ Aligned | ✅ Aligned |
| **Driver Mgmt** | N/A | ✅ Aligned | ✅ Aligned |
| **Vehicles** | N/A | ✅ Aligned | ⚠️ List-only |
| **Payouts** | N/A | ✅ Aligned | ✅ Aligned |
| **Loyalty** | ❌ **Missing** | N/A | ⚠️ Admin-only |
| **B2B Pricing** | N/A | N/A | ❌ **Missing UI** |
| **Wallet** | ✅ Aligned | N/A | N/A |

---

## Detailed Findings

### ✅ Fully Aligned (No Action Needed)

| Backend Route | Rider App Service | Driver App Service | Admin Panel |
|--------------|-------------------|-------------------|-------------|
| `POST /auth/register` | `auth_service.dart` | `auth_service.dart` | — |
| `POST /auth/login` | `auth_service.dart` | — | — |
| `GET /auth/profile` | `auth_service.dart` | `auth_service.dart` | `AuthContext.tsx` |
| `PATCH /auth/profile` | `auth_service.dart` | `auth_service.dart` | — |
| `POST /auth/logout` | `auth_service.dart` | `auth_service.dart` | — |
| `POST /auth/fcm-token` | `notification_service.dart` | `notification_service.dart` | — |
| `POST /auth/2fa/send` | `auth_service.dart` | `auth_service.dart` | — |
| `POST /auth/2fa/verify` | `auth_service.dart` | `auth_service.dart` | — |
| `POST /rides` | `ride_service.dart` | — | — |
| `POST /rides/estimate` | `ride_service.dart` | — | — |
| `GET /rides/history` | `ride_history_service.dart` | `ride_history_service.dart` | — |
| `GET /rides/:id` | `ride_service.dart` | — | — |
| `PUT /rides/:id/status` | `ride_service.dart` | `ride_service.dart` | — |
| `POST /rides/:id/rate` | `ride_service.dart` | — | — |
| `POST /rides/:id/rate-rider` | — | `ride_service.dart` | — |
| `POST /rides/:id/tip` | `ride_service.dart` | — | — |
| `POST /deliveries` | `delivery_service.dart` | — | — |
| `POST /deliveries/quote` | `delivery_service.dart` | — | — |
| `GET /deliveries/:id` | `delivery_service.dart` | — | — |
| `GET /deliveries/history` | `delivery_service.dart` | — | — |
| `GET /payments/methods` | `payment_service.dart` | — | — |
| `POST /payments/methods` | `payment_service.dart` | — | — |
| `DELETE /payments/methods/:id` | `payment_service.dart` | — | — |
| `POST /payments/initiate` | `payment_service.dart` | — | — |
| `POST /payments/verify` | `payment_service.dart` | — | — |
| `GET /payments/wallet/balance` | `wallet_service.dart` | — | — |
| `GET /payments/wallet/transactions` | `wallet_service.dart` | — | — |
| `POST /payments/wallet/add` | `wallet_service.dart` | — | — |
| `POST /payments/wallet/withdraw` | `wallet_service.dart` | — | — |
| `GET /payments/history` | `payment_service.dart` | — | — |
| `GET /places/saved` | `places_service.dart` | — | — |
| `POST /places/saved` | `places_service.dart` | — | — |
| `PUT /places/saved/:id` | `places_service.dart` | — | — |
| `DELETE /places/saved/:id` | `places_service.dart` | — | — |
| `GET /places/recent` | `places_service.dart` | — | — |
| `POST /places/recent` | `places_service.dart` | — | — |
| `GET /places/search` | `places_service.dart` | — | — |
| `GET /contacts` | `contacts_service.dart` | — | — |
| `GET /contacts/emergency` | `contacts_service.dart` | — | — |
| `POST /contacts/emergency` | `contacts_service.dart` | — | — |
| `DELETE /contacts/emergency/:id` | `contacts_service.dart` | — | — |
| `POST /promotions/apply` | `promotion_service.dart` | — | — |
| `GET /promotions/mine` | `promotion_service.dart` | — | — |
| `GET /promotions/available` | `promotion_service.dart` | — | — |
| `POST /support` | `support_service.dart` | `support_service.dart` | — |
| `GET /support` | `support_service.dart` | `support_service.dart` | — |
| `POST /support/:id/reply` | `support_service.dart` | `support_service.dart` | — |
| `GET /support/admin/all` | — | — | `SupportPage.tsx` |
| `POST /support/admin/:id/reply` | — | — | `SupportPage.tsx` |
| `POST /support/admin/:id/close` | — | — | `SupportPage.tsx` |
| `GET /chat/rides/:id/messages` | `chat_service.dart` | `chat_service.dart` | — |
| `POST /chat/rides/:id/messages` | `chat_service.dart` | `chat_service.dart` | — |
| `POST /chat/rides/:id/read` | — | `chat_service.dart` | — |

---

### ⚠️ Gaps & Mismatches

#### 1. Rider App — Missing Loyalty Integration

> [!IMPORTANT]
> Backend has 5 loyalty endpoints (`/loyalty/account`, `/history`, `/rewards`, `/redeem`, `/redemptions`). The **rider app has no loyalty service** to consume these.

**Action:** Create `loyalty_service.dart` in the rider app and add a Loyalty tab/page.

---

#### 2. Rider App — Missing `chat/read` Call

Backend: `POST /chat/rides/:rideId/read`
Driver app: ✅ calls via `chat_service.dart`
Rider app: ❌ **missing** — rider never marks messages as read

**Action:** Add `markAsRead(rideId)` to rider's `chat_service.dart`.

---

#### 3. Rider App — Missing Delivery Proof Upload

Backend: `POST /deliveries/:rideId/proof`
Rider app: ❌ **missing** — no call to upload proof of delivery

**Action:** If the rider (sender) should upload proof, add it to `delivery_service.dart`.

---

#### 4. Admin Panel — Missing B2B Account Management UI

Backend: 4 new B2B endpoints (`GET/POST /admin/b2b/accounts`, `GET/PUT /admin/b2b/accounts/:id`)
Admin panel: ❌ **no B2B page exists**

**Action:** Create a `B2BAccountsPage.tsx` component with CRUD functionality.

---

#### 5. Admin Panel — Deliveries Page Uses Rides Endpoint

The `DeliveriesPage.tsx` calls `/v1/admin/rides` and filters client-side. Backend has a dedicated `/deliveries/history` endpoint but no admin-specific deliveries endpoint.

**Action (low priority):** Either add `GET /admin/deliveries` to backend or leave as-is since both rides and deliveries share the same collection.

---

#### 6. Admin Panel — Missing Disputes Backend Endpoint

`DisputesPage.tsx` calls `GET /v1/admin/disputes` and `POST /v1/admin/disputes/:id/resolve`.
Backend `admin.routes.ts`: ❌ **No disputes routes exist**.

> [!WARNING]
> The Disputes page will always 404 because the backend has no `/admin/disputes` endpoints.

**Action:** Add dispute CRUD endpoints to `admin.routes.ts`, or remove/disable the Disputes page.

---

#### 7. Admin Panel — Missing Pricing History Endpoint

`PricingHistory.tsx` calls `GET /v1/admin/history/pricing`.
Backend: ❌ **No `/admin/history/pricing` route exists**.

**Action:** Add a pricing change audit log endpoint or disable the History tab.

---

#### 8. Driver App — Missing `support/:id` Detail Endpoint

Rider app calls `GET /support/:ticketId` to fetch a single ticket.
Driver app `support_service.dart`: ❌ **no equivalent call** — can only list tickets and reply.
Backend: has `GET /support/:id` via the `getMyTickets` pattern (no explicit single route).

**Action (low priority):** The backend may support `GET /support/:id` implicitly, but the driver app doesn't use it.

---

#### 9. Driver App — Missing `chat/rides/:id/status` Call

Backend: `GET /chat/rides/:rideId/status`
Driver app `ApiConstants`: has `chatStatus = '/api/v1/chat/rides/{rideId}/status'` defined but ❌ **never called** from `chat_service.dart`.

**Action (low priority):** Wire up the chat status call if needed for UI indicators.

---

### ✅ Base URL Configuration — All Correct

| Client | Base URL Config | Resolves To |
|--------|----------------|-------------|
| Rider App | `http://10.0.2.2:5000` (Android) / `http://localhost:5000` (Web/iOS) | ✅ Correct |
| Driver App | `http://10.0.2.2:5000` (Android) / `http://localhost:5000` (Web/iOS) | ✅ Correct |
| Admin Panel | `VITE_API_URL \|\| http://localhost:5000/api` + `/v1/...` paths | ✅ Resolves to `/api/v1/...` ✅ |

---

## Priority Action Items

| # | Priority | Item | Client |
|---|----------|------|--------|
| 1 | 🔴 High | Add disputes backend endpoints or remove Disputes page | Admin |
| 2 | 🔴 High | Create B2B Accounts admin page | Admin |
| 3 | 🟡 Medium | Create `loyalty_service.dart` + Loyalty UI | Rider |
| 4 | 🟡 Medium | Add pricing history audit log endpoint | Admin |
| 5 | 🟢 Low | Add `markAsRead()` to rider chat service | Rider |
| 6 | 🟢 Low | Add delivery proof upload to rider app | Rider |
| 7 | 🟢 Low | Wire chat status endpoint in driver app | Driver |
