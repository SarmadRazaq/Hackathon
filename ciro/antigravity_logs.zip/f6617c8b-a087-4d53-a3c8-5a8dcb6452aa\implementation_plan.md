# Remediation Implementation Plan

Goal: Address critical and recommended findings from the Production Readiness Audit.

## User Review Required
> [!IMPORTANT]
> **Backend CORS**: We will modify `server.ts` to strictly enforce `CORS_ORIGINS` in production. If this env var is missing in production, the server will default to a safe list or block requests.
> **Admin Panel**: We will add a check in `vite.config.ts` to warn or fail if `VITE_API_URL` is missing during build.

## Proposed Changes

### Backend (`backend`)
#### [MODIFY] [server.ts](file:///f:/BlackLivery/backend/src/server.ts)
- Add a log warning on startup if `CORS_ORIGINS` is not set in production.
- (Existing logic already parses `CORS_ORIGINS`, so no functional change needed there).

#### [MODIFY] [.env.example](file:///f:/BlackLivery/backend/.env.example)
- Add `CORS_ORIGINS` variable example.

### Admin Panel (`frontend-adminpanel`)
#### [MODIFY] [vite.config.ts](file:///f:/BlackLivery/frontend-adminpanel/vite.config.ts)
- Add a check for `VITE_API_URL` in the config.

## Verification Plan

### Backend
- **Automated**: Run `npm run dev` and verify server starts.
- **Manual**: Check logs to see CORS origins being loaded.

### Admin Panel
- **Manual**: Run `npm run build` without `VITE_API_URL` and verify it warns/fails (as implemented).
