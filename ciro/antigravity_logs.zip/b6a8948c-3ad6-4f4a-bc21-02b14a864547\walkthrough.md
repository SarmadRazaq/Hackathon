# Walkthrough: Mobile Issues Fix

## Summary

Fixed three critical issues reported by the mobile developer:
1. **Not mobile responsive** — Phaser game rendered tiny on portrait phones
2. **Camera/microphone permissions not requested** — no permission prompt shown in WebView
3. **"Waiting for date" stall** — video init failed silently, no UI feedback

## Changes Made

### 1. Viewport Meta Tag — [layout.tsx](file:///f:/Git/game-project/client/app/layout.tsx)
- Added a separate `Viewport` export with `width: device-width`, `initialScale: 1`, `maximumScale: 1`, `userScalable: false`, `viewportFit: cover`
- Uses Next.js 14+ `Viewport` type (required as separate export, not inside `metadata`)

### 2. Phaser RESIZE Mode — [dateNightGame.ts](file:///f:/Git/game-project/client/game/dateNightGame.ts)
- Changed from fixed `1280×720` with `FIT` mode to `RESIZE` mode with `100%` width/height
- Game now fills the parent container and adapts to any screen size, including mobile portrait

### 3. Responsive Lobby — [LobbyScene.ts](file:///f:/Git/game-project/client/game/scenes/LobbyScene.ts)
- Fixed duplicate `DEFAULT_PROFILE_IMAGE` property declaration
- Added `rfs()` helper (responsive font size) that clamps text between min/max based on shorter screen dimension
- Made card width/height, avatar size, button width, and stat spacing responsive using `Math.min()` clamping
- All font sizes now scale from mobile-friendly minimums to desktop maximums

### 4. Responsive Waiting Room — [WaitingRoomScene.ts](file:///f:/Git/game-project/client/game/scenes/WaitingRoomScene.ts)
- Added `rfs()` helper, same pattern as LobbyScene
- Radar animation radius scaled to `Math.min(width, height) * 0.15`
- Title uses word-wrap for portrait screens
- Tips card, progress bar, and match-found card all scale with screen dimensions
- Fixed null-safety: `remotePlayer.id` → `remotePlayer?.id`

### 5. Permission Request Flow — [videoService.ts](file:///f:/Git/game-project/client/lib/services/videoService.ts)
- Added `requestPermissions()` method that:
  1. Sends `REQUEST_PERMISSIONS` to Flutter via bridge (for native permission dialogs in WebView)
  2. Calls `navigator.mediaDevices.getUserMedia()` to trigger browser permission prompt
  3. Returns `'granted' | 'denied' | 'error'` for UI to act on

### 6. Video Permission UI — [VideoContainer.tsx](file:///f:/Git/game-project/client/components/DateNight/VideoContainer.tsx)
- Added `permissionState` tracking: `'checking' | 'granted' | 'denied' | 'error' | 'initializing' | 'ready'`
- **Before Zego init**, explicitly calls `videoService.requestPermissions()` to trigger the browser/WebView permission prompt
- Shows clear UI states:
  - 🔒 **Permission Denied** — explains what happened + retry button + settings instructions
  - ⚠️ **Connection Error** — explains the issue + retry button
  - 📹 **Checking** — "Requesting camera & microphone access..." spinner
  - 🔌 **Initializing** — "Connecting to video service..." spinner
- Made video controls responsive with `clamp()` sizing

### 7. Audio Recorder WebView Fix — [AudioRecorder.tsx](file:///f:/Git/game-project/client/components/DateNight/AudioRecorder.tsx)
- Added Flutter bridge `requestPermissions({ microphone: true })` call before `getUserMedia`
- Gives Flutter 800ms to process the native permission dialog before browser prompt

### 8. Flutter Bridge — [flutterBridge.ts](file:///f:/Git/game-project/client/lib/utils/flutterBridge.ts)
- Added `REQUEST_PERMISSIONS` event type
- Added `requestPermissions()` convenience method

## Build Verification

- ✅ `npm run build` completed successfully
- ✅ All pages collected and static pages generated (9/9)
- ✅ Page optimization finalized

## Important Note for Mobile Developer

> [!IMPORTANT]
> The **Flutter WebView** must handle the `request_permissions` message from the bridge and trigger native Android/iOS permission dialogs. The web side now sends:
> ```json
> { "type": "request_permissions", "data": { "camera": true, "microphone": true } }
> ```
> The Flutter side should listen for this message and call the platform permission APIs before the WebView's `getUserMedia` will work.
