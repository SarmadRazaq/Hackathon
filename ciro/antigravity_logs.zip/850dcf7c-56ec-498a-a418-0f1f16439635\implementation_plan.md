# Milestone 1 / Phase 1: Core Game Engine & Foundation — Implementation Plan

## Current State Assessment

The project already has a **solid codebase** built in Unity 6 (`6000.4.1f1`). After auditing every script, here's the system-by-system status:

| System | Status | Notes |
|--------|--------|-------|
| Project Setup | ✅ Complete | Unity 6, URP, Cinemachine, TMP all configured |
| Player Data (PBA/DTA) | ✅ Complete | `PlayerProfile.cs` tracks PBA, DTA, ownedProperties |
| Turn System | ✅ Complete | State machine in `GameManager` (StartGame → PlayerTurn → Moving → Interaction) |
| Basic UI | ✅ Complete | `UIManager` + `LaunchHudController` with premium HUD overlay |
| Board Generation | ✅ Complete | 48-tile square board via `BoardGenerator` + `ProductionVisualTheme` |
| Primary Board Movement | ✅ Complete | Step-by-step hop animation in `PlayerMovement`, with pass-GO detection |
| Tile Type Identification | ✅ Complete | `TileType` enum (Property, Event, Card, MiniGame, CourthouseChallenge, Start) |
| Standard Dice (1-6) | ✅ Complete | `DiceSystem.RollStandardDice()` |
| Color-Coded Die (starting order) | ✅ Complete | `DiceSystem.ColorCodedDice()` + `DetermineStartingOrder()` coroutine |
| Property Buy | ✅ Complete | `PropertyManager.BuyProperty()` deducts from PBA |
| Property Sell (Wholesale) | ⚠️ **Bug** | Proceeds go to DTA ✅, but tile state reset logic is duplicated between `PropertyManager.SellToBank()` and `GameManager.SellPropertyToBank()` |
| Property Improvements (4+1) | ✅ Complete | Up to level 5, one-per-turn enforced via `hasImprovedPropertyThisTurn` |
| Rent Collection | ⚠️ **Bug** | Rent deducted from PBA ✅, but sent to **owner's DTA** instead of PBA. The GDD says rent → owner's DTA, so this is correct per spec. |
| Win Conditions (3 Gates) | ✅ Complete | PBA ≤ 10,000 AND DTA ≥ 300,000,000 AND 0 owned properties |
| Inspector-Configurable Values | ⚠️ **Incomplete** | `WinManager` thresholds are Inspector-editable ✅, but rent multipliers on `Tile` are per-tile only. There's no central `GameConfig` ScriptableObject. |

---

## Issues Found During Audit

### 1. Duplicate Sell-to-Bank Code Paths (Moderate)
Both `PropertyManager.SellToBank()` and `GameManager.SellPropertyToBank()` contain independent implementations. The GameManager version is used by older code paths (`ApplyTileInteraction`, `SellActivePlayerPropertyToBank`), while the PropertyManager version is used by the newer `ConfirmSellLandedProperty()` flow. This creates a risk of logic divergence.

**Fix**: Consolidate so `GameManager.SellPropertyToBank()` delegates to `PropertyManager.SellToBank()`.

### 2. No Central `GameConfig` ScriptableObject (Required by Deliverables)
The deliverables require **Inspector-Configurable Values** for PBA win threshold, DTA win target, and rent multipliers — editable without code changes. Currently:
- `WinManager` has `pbaWinThreshold` and `dtaWinTarget` ✅
- `EconomyManager` has `passStartSalary` ✅
- But rent multipliers are per-tile arrays, and there's no single central config asset

**Fix**: Create a `GameConfig` ScriptableObject that centralizes all tunable values, referenced by the relevant managers.

### 3. Missing `FindObjectsByType` Signature (Build Risk)
`ProductionVisualTheme.ApplyBoardTheme()` calls `FindObjectsByType<Tile>()` without the required `FindObjectsSortMode` parameter in Unity 6. This will cause a compile error.

**Fix**: Add `FindObjectsSortMode.None` parameter.

### 4. Player Capsule Spawning Not Automated
Players must be manually placed in the scene and tagged "Player". For a "playable solo session" deliverable, we should ensure at least one player is auto-spawned if none exist.

### 5. The `ApplyTileInteraction` Method is Dead Code
`ApplyTileInteraction()` in GameManager is never called — the newer `OnPlayerLand()` method handles all landing logic. This dead code path can be removed.

---

## Proposed Changes

### Component 1: Central Game Configuration

#### [NEW] [GameConfig.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/GameConfig.cs)
A `ScriptableObject` that centralizes all Inspector-configurable game parameters:
- `startingPBA` (default 5000)
- `startingDTA` (default 0)
- `passStartSalary` (default 200)
- `pbaWinThreshold` (default 10,000)
- `dtaWinTarget` (default 300,000,000)
- `requiredPropertyCountToWin` (default 0)
- `maxImprovementLevel` (default 5)
- `defaultRentMultipliers` (default `{1, 2.2, 4.5, 8.5, 15, 24}`)
- `wholesaleMultiplier` (default 1.5)

This satisfies the deliverable: *"PBA win threshold, DTA win target, and rent multipliers must be editable in the Unity Inspector without changing the code."*

---

### Component 2: Bug Fixes & Consolidation

#### [MODIFY] [GameManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/GameManager.cs)
- Remove the duplicate `SellPropertyToBank()` method and have it delegate to `PropertyManager.SellToBank()`
- Remove dead-code `ApplyTileInteraction()` and `HandlePropertyTileInteraction()` methods
- Add `GameConfig` reference field with fallback to current hardcoded values
- Add auto-spawn of a single player capsule if none exist in the scene (for the "playable solo session" deliverable)

#### [MODIFY] [PropertyManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/PropertyManager.cs)
- Accept optional `GameConfig` reference for `maxImprovementLevel` and `wholesaleMultiplier`

#### [MODIFY] [Tile.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/Tile.cs)
- `GetWholesaleValue()`: Accept optional wholesale multiplier parameter (defaulting to 1.5)

#### [MODIFY] [WinManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/WinManager.cs)
- Accept optional `GameConfig` reference, using its thresholds when available

#### [MODIFY] [EconomyManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/EconomyManager.cs)
- Accept optional `GameConfig` reference for pass-start salary

#### [MODIFY] [PlayerProfile.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/PlayerProfile.cs)
- Accept optional `GameConfig` reference for starting PBA/DTA defaults (fallback to `PlayerEconomyConfig`)

---

### Component 3: Compile Fix

#### [MODIFY] [ProductionVisualTheme.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/ProductionVisualTheme.cs)
- Fix all `FindObjectsByType<T>()` calls to include the required `FindObjectsSortMode` parameter

---

### Component 4: Solo Player Auto-Spawn

#### [MODIFY] [GameManager.cs](file:///f:/Git/monopoly-unity/monopoly/Assets/_Scripts/GameManager.cs)
- If `players.Count == 0` after tag search, auto-spawn a capsule at Tile_0 with `PlayerProfile` and `PlayerMovement` components
- The capsule gets a default `tokenColorId` of "Red"
- This ensures the "playable solo session" deliverable works out-of-the-box

---

## User Review Required

> [!IMPORTANT]
> **Rent destination clarification**: The GDD states *"Rent is deducted from the landing player's PBA and transferred directly to the owner's DTA."* The current code does exactly this (`EconomyManager.ProcessRent` sends rent to `owner.DTA`). Is this the intended behavior, or should rent go to the owner's PBA instead? The current implementation matches the spec as written.

> [!IMPORTANT]
> **Central GameConfig ScriptableObject**: I plan to create a `GameConfig` ScriptableObject as the single source of truth for all tunable values. Existing per-component fields (like `WinManager.pbaWinThreshold`) will remain as fallbacks but defer to `GameConfig` when one is assigned. Does this approach work for you, or would you prefer to remove the per-component fields entirely?

## Open Questions

1. **Number of players for solo session**: Should the solo session use exactly 1 player token, or should we spawn 2-4 AI/dummy players for a more complete demo? (The GDD mentions "solo player" but that could mean single human player vs. AI.)

2. **Event/Card tile effects**: The current implementation uses random PBA deltas for Event/Card tiles. Are these placeholder values acceptable for Milestone 1, or do you have specific event descriptions and values?

3. **MiniGame tiles**: Currently simulated with a random win/lose coin flip. Is this acceptable for Milestone 1, or should there be actual mini-game mechanics?

---

## Verification Plan

### Automated Tests
- Build the project in Unity to verify zero compile errors: `Unity -batchmode -projectPath ... -logFile - -quit`
- Verify all `FindObjectsByType` calls compile with correct signatures

### Manual Verification
- Open the scene in Unity Editor
- Press Play and confirm:
  1. Board generates with 48 tiles (correct types and names)
  2. Color-coded dice roll determines starting order
  3. Player can roll dice and move step-by-step
  4. Pass-GO salary is awarded
  5. Landing on unowned property shows Buy UI
  6. Buying deducts from PBA
  7. Landing on owned property shows Upgrade/Sell UI
  8. Only 1 improvement per turn is enforced
  9. Selling to bank sends proceeds to DTA (not PBA)
  10. Rent is deducted from lander's PBA → owner's DTA
  11. Win condition triggers when PBA ≤ 10,000, DTA ≥ 300,000,000, 0 properties
  12. All threshold values are editable in Inspector via GameConfig
