# Step-by-Step: Restore Fusion CodeGen (Weaver)

Your version: **Fusion 2.0.12 Stable (Build 1861)**

> [!IMPORTANT]
> Your config files have already been backed up to `FusionConfigBackup/` in your project root.

---

## Step 2: Download the Fusion SDK

1. Open your browser and go to: **https://dashboard.photonengine.com/download/fusion**
2. Sign in with your Photon account
3. Download the **Fusion 2 SDK** `.unitypackage` file (make sure it's Fusion 2, not Fusion 1)

> [!TIP]
> If you originally got Fusion from the **Unity Asset Store**, you can also re-download it from: **Window → Package Manager → My Assets → search "Fusion"**

---

## Step 3: Import ONLY the CodeGen Folder

1. In Unity, go to **Assets → Import Package → Custom Package...**
2. Browse to the `.unitypackage` you just downloaded
3. The import dialog will appear showing all files — **click "None" first** to deselect everything
4. Then expand the tree: `Assets → Photon → Fusion → CodeGen`
5. **Check/select** the entire `CodeGen` folder. You should see these 3 files (+their .meta files):
   - ☑ `Fusion.CodeGen.asmdef`
   - ☑ `Fusion.CodeGen.cs`
   - ☑ `Fusion.CodeGen.User.cs`
6. Click **Import**

![What the import dialog should look like - select only the CodeGen folder](info)

---

## Step 4: Verify the Import

After importing, Unity will recompile automatically. Check:

1. **The folder exists**: In Unity's Project window, navigate to `Assets/Photon/Fusion/` — you should now see a `CodeGen` folder
2. **No compile errors**: Check the Console window (Window → General → Console)
3. **The weaver runs**: You should see Fusion weaver log messages in the Console during compilation

---

## Step 5: Test with a NetworkBehaviour Script

1. Create a new test script in `Assets/Scripts/`:

```csharp
using Fusion;
using UnityEngine;

public class TestNetwork : NetworkBehaviour
{
    [Networked] public int TestValue { get; set; }

    public override void FixedUpdateNetwork()
    {
        // Just a test
        Debug.Log("Weaving works!");
    }
}
```

2. Wait for Unity to recompile
3. **If no error appears** → ✅ The weaver is working! Delete the test script.
4. **If the error still appears** → Continue to Step 6

---

## Step 6: Force the Weaver (Only if Step 5 still fails)

If the error persists after importing CodeGen:

1. Go to **Tools → Fusion → Run Weaver** in Unity's menu bar
2. This forces a clean recompile with the weaver
3. If that still fails, try:
   - Close Unity
   - Delete the `Library` folder in your project root
   - Reopen Unity (it will rebuild everything from scratch — this takes a few minutes)

---

## Step 7: Restore Config (Only if configs were overwritten)

If you accidentally imported the full SDK and your configs got overwritten:

1. Your backups are at:
   - `FusionConfigBackup/NetworkProjectConfig.fusion`
   - `FusionConfigBackup/PhotonAppSettings.asset`
2. Copy them back to `Assets/Photon/Fusion/Resources/`

---

## Quick Summary

| Step | Action | Time |
|------|--------|------|
| ~~1~~ | ~~Back up configs~~ | ✅ Done |
| 2 | Download Fusion SDK | ~2 min |
| 3 | Import only CodeGen folder | ~1 min |
| 4 | Verify import + recompile | ~30 sec |
| 5 | Test with NetworkBehaviour script | ~1 min |
| 6 | Force weaver (if needed) | ~1 min |
