# Walkthrough: 6 Issues Fixed

## Files Changed

| File | Issue(s) | Change |
|------|----------|--------|
| [my_rides_screen.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/presentation/pages/my_rides_screen.dart) | #6 | Safely extract nested `dropoffLocation.address`, `pricing.estimatedFare`, `pricing.currency` |
| [user_model.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/core/models/user_model.dart) | #2, #5 | Parse `riderDetails` for rating/totalTrips |
| [account_screen.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/presentation/pages/account_screen.dart) | #2, #5 | Use actual rating instead of hardcoded `'5.0'` |
| [RideService.ts](file:///F:/BlackLivery/backend/src/services/RideService.ts) | #1, #5 | Increment rider `totalTrips` on completion; record rider debit transaction for wallet history |
| [auth_service.dart](file:///F:/BlackLivery/mobile/blackliveryrider/lib/core/services/auth_service.dart) | #3 | Add `POST /api/v1/auth/login` to Google/Apple sign-in |

---

## Issue-by-Issue Summary

### Issue 1: Wallet Only Shows Cancellation Fee ✅
**Root cause:** Card/external ride payments went through escrow without recording a `transactions` entry for the rider. Only `chargeWalletForRide` (wallet payments) and `cancellation_fee` debits were recorded.

**Fix:** Added a display-only debit record to the `transactions` collection in `settleRidePayment()` for non-wallet payments.

### Issues 2 & 5: Rating & Ride Count Not Updating ✅
**Root cause:** Backend writes rider stats to `riderDetails.rating` / `riderDetails.totalTrips`, but `User.fromJson` only parsed `driverDetails`. Account screen hardcoded `'5.0'` for riders.

**Fix:** `User.fromJson` now parses `riderDetails` and falls back to top-level fields. Account screen uses actual rating. Backend now increments `riderDetails.totalTrips` on ride completion.

### Issue 3: Sessions & Login History Empty ✅
**Root cause:** Google and Apple sign-in methods never called `POST /api/v1/auth/login` to record sessions. Only email login did.

**Fix:** Added session recording calls to `signInWithGoogle` and `signInWithApple`.

### Issue 4: Driver App Toggles ℹ️
**Finding:** Toggles work correctly. `DriverPreferencesProvider` stores preferences in SharedPreferences, and `RideProvider` auto-declines unwanted rides. No fix needed.

### Issue 6: Delivery Screen Red Error ✅
**Root cause:** `_buildDeliveryCard` cast `delivery['dropoffAddress']` to `String?` but backend returns address nested inside `delivery['dropoffLocation']['address']`. Same for fare/currency inside `pricing`.

**Fix:** Safe extraction from both flat and nested structures.

## Verification

- ✅ Backend `tsc --noEmit` compiles with exit code 0
- ⏳ Hot restart rider app to verify delivery tab, rating display, and session recording
- ⏳ Log out and back in to verify sessions populate
