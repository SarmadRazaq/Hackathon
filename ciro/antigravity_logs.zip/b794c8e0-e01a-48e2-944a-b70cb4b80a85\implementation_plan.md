# Settings & Support Refactor Plan

## Goal
Replace the current "Grid Modal" implementation for Settings and Support with dedicated, full-screen navigations (`SettingsScreen` and `SupportScreen`) that offer a standard, list-based UI.

## Components
- [NEW] `src/screens/settings/SettingsScreen.tsx`:
    - Vertical list with sections: "Account", "Security", "Data", "Danger Zone".
    - Integrating existing logic for Edit Profile, Change Password, Linked Accounts, Delete Account.
    - Uses existing Modals for specific actions (Edit Profile, Change Password) but launched from this screen.
- [NEW] `src/screens/settings/SupportScreen.tsx`:
    - Vertical list: Help Center, Feedback, Rate Us, Privacy Policy, Export Data.
    - Uses `Linking` for external actions.

## Navigation
- [MODIFY] `src/navigation/RootNavigator.tsx`:
    - Register `Settings` and `Support` screens.
- [MODIFY] `src/screens/ProfileScreen.tsx`:
    - Replace `OptionGridModal` with `navigation.navigate('Settings')` and `navigation.navigate('Support')`.

## UI/UX
- Consistent Dark Theme.
- Standard list items with left icon, label, right chevron.
- Headers with back button.
