# Alignment Implementation Plan

## Goal
Align the Driver App's UI with the Rider App (Gold/Black theme) and synchronize the Frontend Data Models with the Backend API (TypeScript).

## User Review Required
> [!IMPORTANT]
> **Data Model Changes**: The `Vehicle` model in the Driver App currently expects `make`, `model`, and `color`, but the Backend only stores `name` (combined) and does *not* store `color`.
> **Action**: I will update the Frontend `Vehicle` model to use `name` and remove/hide `color` input, or hardcode it for now if required by UI. I will also map Backend `isApproved` boolean to Frontend `status` string.

## Proposed Changes

### 1. Theme Alignment (UI)
**File**: `driver/lib/core/theme/app_theme.dart`
-   **Colors**: Replace Green (`0xFF4CAF50`) primary with Gold (`0xFFD2BF9F`). Update background to `0xFF181818`.
-   **Fonts**: Ensure Usage of `GoogleFonts.inter` or `outfit` matches Rider (Rider uses default/Inter).
-   **Inputs**: Update `InputDecorationTheme` to use Gold borders for focus state.

### 2. Data Model Synchronization (Backend -> Frontend)

#### User Model
**File**: `driver/lib/features/auth/data/models/user_model.dart`
-   [MODIFY] Update `fromJson` to map:
    -   Backend `uid` -> Frontend `id`
    -   Backend `photoURL` -> Frontend `profileImage`
    -   Backend `displayName` -> Frontend `firstName` (split string if necessary)
    -   Backend `driverStatus.state` -> Frontend `status`

#### Vehicle Model
**File**: `driver/lib/features/auth/data/models/vehicle_model.dart`
-   [MODIFY] Update fields:
    -   Remove `make` and `model`, add `name`.
    -   Remove `color`.
    -   Add `seats`, `category`.
    -   Map `isApproved` (bool) -> `status` (string).

### 3. Service Updates
**Files**: `AuthService` and `DriverService` (Dart)
-   [MODIFY] Ensure `register` and `addVehicle` payloads match the Backend expects.
    -   `register`: Send `displayName` instead of `firstName`/`lastName`.
    -   `addVehicle`: Send `name` instead of `make`/`model`.

## Verification Plan

### Automated
1.  **Build**: Run `flutter build apk` to observe compilation errors resulting from model changes.
2.  **Fix**: Resolve compilation errors in screens that use `user.firstName` or `vehicle.make` (e.g., `ProfileScreen`, `VehicleInfoScreen`).

### Manual
1.  **Theme Check**: Launch app -> Verify Splash, Login, and Home screens use Gold/Black theme.
2.  **Login Flow**: Log in -> Verify User details load correctly (no null errors).
3.  **Vehicle Flow**: Navigate to Vehicles -> Verify list loads correctly without JSON parsing errors.
