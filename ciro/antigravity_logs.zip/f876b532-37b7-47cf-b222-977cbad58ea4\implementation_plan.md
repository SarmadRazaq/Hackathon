# Fix Host Movement Sluggishness

## Problem

The **host (Unity Editor)** movement feels very slow and sluggish compared to the **client (build)**, which moves smoothly. This regression appeared after multiplayer was added.

## Root Cause

The issue is a **position tug-of-war** between `NetworkTransform` and the root-sync logic in `PlayerNetworkSetup.LateUpdate()`.

Here's what happens every frame on the **host's own player**:

1. `FirstPersonController.Update()` → moves the `PlayerVisual` child via `CharacterController.Move()`
2. `PlayerNetworkSetup.LateUpdate()` → copies the child's world position to the root, resets child to identity ✅
3. `NetworkTransform` (still enabled!) → **overwrites the root position with its interpolated/buffered value**, effectively dragging the root back toward a stale position ❌

This creates a frame-by-frame fight: root-sync pushes the root forward, NetworkTransform pulls it back. The result is sluggish, dampened movement.

**Why the client doesn't have this problem**: In `PlayerNetworkSetup` line 125-133, NetworkTransform is already correctly disabled for the client's local player (`HasInputAuthority && !HasStateAuthority`). But the host's own player has **both** `HasInputAuthority` AND `HasStateAuthority`, so it doesn't hit that condition.

## Proposed Changes

### FirstPersonController Movement

#### [MODIFY] [PlayerNetworkSetup.cs](file:///f:/Courses/Subsurface_SENDV2/Subsurface_SEND/Assets/Scripts/PlayerNetworkSetup.cs)

Disable `NetworkTransform` interpolation on the **host's own local player** too. The host doesn't need NetworkTransform to interpolate its own root — root-sync is already handling it. NetworkTransform on remote player objects (on the host) will remain enabled and continue broadcasting positions to clients.

Change the condition from:
```csharp
// Only client's local player
if (isMine && !networkObject.HasStateAuthority)
```

To:
```csharp
// ANY local player (host or client) — root-sync drives the root, not NetworkTransform
if (isMine)
```

> [!IMPORTANT]
> This means `NetworkTransform` is disabled on the local player's own object for BOTH host and client. However, because the host has `HasStateAuthority`, Fusion treats the root transform as the authoritative source and will still broadcast its position to all clients via the `NetworkRunner` tick. The `NetworkTransform` component being disabled only stops it from **overwriting** the local transform — it does NOT stop position replication for the state authority.

---

#### [MODIFY] [PlayerNetwork.cs](file:///f:/Courses/Subsurface_SENDV2/Subsurface_SEND/Assets/Scripts/PlayerNetwork.cs)

Change `FixedUpdate` to `Update` for the remote-player position application. Since `FirstPersonController` runs in `Update` and `PlayerNetworkSetup.LateUpdate` copies positions in `LateUpdate`, reading input in `FixedUpdate` can miss frames or apply at inconsistent rates. Using `Update` keeps the timing aligned.

> [!NOTE]
> This is a minor secondary fix. The primary fix (disabling NT on host's local player) is what resolves the sluggishness.

## Open Questions

None — the fix is straightforward and low-risk. Remote players continue to be driven by the existing `PlayerNetwork` + `NetworkTransform` pipeline.

## Verification Plan

### Manual Verification
1. Host the game from Unity Editor — movement should now feel as responsive as it was before multiplayer
2. Join from a build — client movement should remain smooth (no regression)
3. Both players should see each other moving correctly
