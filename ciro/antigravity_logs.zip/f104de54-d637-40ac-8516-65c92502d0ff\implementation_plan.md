# Pipeline Optimization & Live Rescue Tracking

You raised a very valid concern: 40 seconds is too long for a live hackathon demo where judges have limited patience. We can solve this while adding your brilliant idea for Live Rescue Tracking.

## Strategy 1: Reducing Pipeline Time (Agent Consolidation)
The reason it takes 40 seconds is because 7 LLMs are generating text one after the other. We can retain ALL of the advanced features (Vision, Constraints, Urdu) but execute them much faster by consolidating the agents.

### [MODIFY] [orchestrator.py](file:///f:/Hackathon/ciro/backend/agents/orchestrator.py)
We will collapse the 7-agent pipeline back down to **5 Agents**:
1. **Combine Vision + Ingestion**: We merge `vision_analyzer` and `signal_ingestor` into a single `multimodal_ingestor`. It will look at the image AND read the text in a single API call, outputting both the vision JSON and the text classification.
2. **Combine Planning + Verification**: We merge `response_planner` and `plan_verifier` into a single `safe_response_planner`. We use advanced prompt engineering to force it to plan and self-verify against constraints in one go.

**Result:** The pipeline time will drop from ~40 seconds back down to **~15-20 seconds** without losing a single feature.

## Strategy 2: Live Rescue Tracking & ETA 🚑
This is an incredible idea that will make the map feel truly alive. 

### [MODIFY] [orchestrator.py](file:///f:/Hackathon/ciro/backend/agents/orchestrator.py)
- Instruct the `execution_simulator` to output a specific JSON block at the end of its report: `__RESCUE_DISPATCH__: {"unit": "Ambulance 4", "eta_mins": 12, "start_lat": 33.6900, "start_lng": 73.0500}`.
- It will automatically calculate a starting coordinate a few kilometers away from the crisis epicenter.

### [MODIFY] [ResultScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/ResultScreen.tsx)
- Extract the `__RESCUE_DISPATCH__` JSON.
- **UI Update:** Display a massive, flashing "Help Arriving in: 12 Mins" banner.
- **Map Update:** 
  1. Draw a `Polyline` (route line) from the Rescue Unit's start coordinate to the Crisis Epicenter.
  2. Drop a 🚑 Marker at the start coordinate.
  3. *Hackathon Flex:* We will use React Native `Animated` to actually animate the Ambulance marker moving along the map towards the crisis zone while the user watches.

## ⚠️ User Review Required

> [!NOTE]
> Are you okay with collapsing the agents? The logs will show 5 agents instead of 7, but the UI will still show the Vision Metrics, the Urdu Translation, and the Danger Polygons. It is the exact same output, just optimized for speed.

## Verification Plan
1. Rewrite `orchestrator.py` to consolidate the agents and add the Rescue Dispatch JSON prompt.
2. Update `ResultScreen.tsx` to parse the ETA and animate the map marker.
3. Run a test and verify the time drops below 20 seconds and the ambulance moves on the map.
