# CIRO Close-Out Plan

This plan details the implementation steps to resolve the 6 outstanding items before the CIRO hackathon demo recording.

## User Review Required

> [!WARNING]
> Action Required: Please review the **Open Questions** section below and provide the necessary credentials/feedback so we can proceed with execution.

## Open Questions

> [!IMPORTANT]
> 1. **Firebase Credentials (Item 1):** Please provide the correct CIRO Firebase project credentials for `mobile/.env`, `google-services.json`, and (if applicable) `GoogleService-Info.plist`.
> 2. **OpenWeather API Key (Item 6):** Do you have an OpenWeather API key, or should I sign up for a free-tier key during execution?
> 3. **NDMA Alerts (Item 6):** Please confirm that option A (Firestore-backed NDMA alerts updated manually or via a cron) is acceptable over a flaky web scraper.

## Proposed Changes

---

### Mobile App - Configuration & Setup

#### [MODIFY] [mobile/.env](file:///f:/Hackathon/ciro/mobile/.env)
- Update Firebase credentials to use the correct CIRO project instead of the portfolio-website.

#### [MODIFY] [mobile/.env.example](file:///f:/Hackathon/ciro/mobile/.env.example)
- Ensure all required keys are listed with placeholder values.

#### [NEW] [mobile/google-services.json](file:///f:/Hackathon/ciro/mobile/google-services.json)
- Overwrite with the correct file from the CIRO Firebase console.

#### [NEW] [mobile/GoogleService-Info.plist](file:///f:/Hackathon/ciro/mobile/GoogleService-Info.plist)
- (Optional depending on iOS scope) Add correct file or remove reference from app.json.

#### [MODIFY] [mobile/app.json](file:///f:/Hackathon/ciro/mobile/app.json)
- Update/remove iOS GoogleService-Info.plist reference if needed.

#### [MODIFY] [.gitignore](file:///f:/Hackathon/ciro/.gitignore)
- Ensure `mobile/.env` is ignored.

---

### Mobile App - UI & Logic

#### [MODIFY] [mobile/src/screens/HomeScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/HomeScreen.tsx)
- Remove hardcoded `DEMO_CRISES` seeding block.
- Rely strictly on the `onSnapshot` Firestore listener for active crises.
- Add `crisesLoading` state and render an empty state when there are zero incidents.

#### [MODIFY] [mobile/src/services/api.ts](file:///f:/Hackathon/ciro/mobile/src/services/api.ts)
- Add `sendCommsMessage` API helper.
- Add `listScenarios` and `runScenario` API helpers.

#### [MODIFY] [mobile/src/screens/CommsScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/CommsScreen.tsx)
- Add a "Send" button to dispatch the drafted message.
- Call `sendCommsMessage` on press, show a success alert, trigger haptics, and clear the draft.

#### [NEW] [mobile/src/screens/TestModeScreen.tsx](file:///f:/Hackathon/ciro/mobile/src/screens/TestModeScreen.tsx)
- Create a new screen to list and execute predefined scenarios.
- Fetch scenarios using `GET /api/scenarios`.
- On selection, run scenario via `POST /api/analyze/scenario/{id}` and navigate to `ResultScreen`.

#### [MODIFY] [mobile/App.tsx](file:///f:/Hackathon/ciro/mobile/App.tsx)
- Register `TestModeScreen` in `RootStackParamList` and stack navigator.
- Add "Test Mode" to the drawer navigator, gated by user role.

---

### Backend - API & Tools

#### [MODIFY] [backend/main.py](file:///f:/Hackathon/ciro/backend/main.py)
- Implement `POST /api/comms/send` to simulate sending a message and write an audit log to Firestore `comms_log`.

#### [MODIFY] [backend/.env](file:///f:/Hackathon/ciro/backend/.env)
#### [MODIFY] [backend/.env.example](file:///f:/Hackathon/ciro/backend/.env.example)
- Add `NASA_FIRMS_API_KEY`, `OPENWEATHER_API_KEY`, and `NDMA_FEED_URL`.

#### [MODIFY] [backend/agents/tools.py](file:///f:/Hackathon/ciro/backend/agents/tools.py)
- Refactor `get_nasa_firms_hotspots` to use the API key from environment variables.
- Refactor `get_pmd_weather` to layer a real OpenWeather call on top of the Open-Meteo fallback.
- Refactor `get_ndma_alerts` to read from a Firestore collection `ndma_alerts`.

---

### Admin Panel

#### [MODIFY] [admin_panel/src/app/comparison/page.tsx](file:///f:/Hackathon/ciro/admin_panel/src/app/comparison/page.tsx)
- Replace mock data fallback with a fetch to `GET /api/comparison/{selectedCrisisId}`.
- Map the backend response to the existing UI interfaces.
- Add a loading skeleton and error state banner.

---

### Documentation

#### [MODIFY] [README.md](file:///f:/Hackathon/ciro/README.md)
- Document the manual Firestore update process for NDMA alerts and new environment variables.

## Verification Plan

### Automated/Manual Testing
- **Item 1:** Start mobile app and verify no Firebase auth errors.
- **Item 2:** Load Home screen with empty DB -> verify empty state. Seed an incident -> verify it appears live. Delete it -> verify it vanishes live.
- **Item 3:** Trigger a crisis and verify the admin comparison page correctly calls `GET /api/comparison/{id}` and renders live data instead of mock values.
- **Item 4:** Draft and send a message in CommsScreen, check Firestore `comms_log` collection for the new record.
- **Item 5:** Ensure Test Mode is accessible in the drawer, tap a scenario, and verify backend pipeline runs and ResultScreen populates.
- **Item 6:** Verify backend API calls to NASA and OpenWeather use actual keys. Test NDMA tool reads from Firestore. Check fallbacks work when keys are unset.
