# Earnings Dashboard Charts Implementation Plan

## Goal
Implement a pixel-perfect "Driver Earnings Dashboard" matching the user's design requirements, including a Daily Earnings Gauge, Weekly Bar Chart, and Monthly Bar Chart, using `fl_chart` and `percent_indicator`.

## Proposed Changes

### Data Model
#### [NEW] [earnings_chart_model.dart](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/lib/features/earnings/data/models/earnings_chart_model.dart)
- Create `EarningsChartData` class to hold:
    - Daily Target & Current Earnings
    - Stats (Total Rides, Total Fare, Total Tips)
    - List of Weekly Data points (Day, Amount)
    - List of Monthly Data points (Month, Amount)
- Create a `MockEarningsData` class to populate this with sample data.

### Widgets
#### [NEW] [daily_earnings_gauge.dart](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/lib/features/earnings/widgets/daily_earnings_gauge.dart)
- Use `CircularPercentIndicator` (from `percent_indicator`) for the gauge.
- Styling:
    - Arc type: `HALF` (open at bottom).
    - Colors: Progress (Gold/Beige - `0xFFD4AF37`), Background (Dark Grey - `0xFF2C2C2C`).
    - Center widget: Column with Amount (Large White) and Target (Small Grey).
- Implement layout for Stats Row and Buttons below the gauge.

#### [NEW] [weekly_bar_chart.dart](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/lib/features/earnings/widgets/weekly_bar_chart.dart)
- Use `BarChart` (from `fl_chart`).
- Styling:
    - Vertical bars with fully rounded caps.
    - Gradient/White color.
    - X-Axis: Days (Mon-Sun).
    - Y-Axis: Hidden.
    - Tooltip on touch.

#### [NEW] [monthly_bar_chart.dart](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/lib/features/earnings/widgets/monthly_bar_chart.dart)
- Similar to Weekly chart but for 12 months (Jan-Dec).
- Denser bars.

### Screen Integration
#### [MODIFY] [earnings_screen.dart](file:///f:/BlackLivery/mobile/rider/blackliverydriver/driver/lib/features/earnings/earnings_screen.dart)
- Remove existing placeholders.
- Instantiate `MockEarningsData`.
- Insert `DailyEarningsGauge`, `WeeklyBarChart`, and `MonthlyBarChart` into the `ListView`.
- Ensure Payouts section remains at the bottom.

## Verification
- Run `flutter run`.
- Verify the UI matches the description/image.
- Check interactions (tooltips).
