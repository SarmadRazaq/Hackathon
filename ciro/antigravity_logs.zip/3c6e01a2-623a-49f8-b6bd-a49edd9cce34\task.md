# Google Cloud Enterprise Upgrade Tasks

- `[x]` **Phase 1: Dependencies**
  - `[x]` Add `google-cloud-aiplatform`, `google-cloud-texttospeech`, `google-cloud-speech`, `google-cloud-storage` to `requirements.txt`.
  - `[x]` Install new packages.
- `[x]` **Phase 2: AI & ML Integration**
  - `[x]` Update `orchestrator.py` to use Vertex AI client/model setup.
  - `[x]` Implement `/api/tts` endpoint in `main.py` using Cloud TTS.
  - `[x]` Implement `/api/transcribe` endpoint in `main.py` using Cloud STT.
  - `[x]` Update React Native mobile app to use `expo-av` to play the TTS audio from backend.
- `[x]` **Phase 3: Maps Integration**
  - `[x]` Replace TomTom with Google Maps Geocoding and Routes API in `tools.py`.
- `[x]` **Phase 4: Cloud Storage Integration**
  - `[x]` Add GCS bucket upload logic for incoming multimodal image data in `main.py` / `orchestrator.py`.
- `[x]` **Phase 5: Deployment Configuration**
  - `[x]` Add `firebase.json` for Firebase Hosting deployment of the web dashboard.
